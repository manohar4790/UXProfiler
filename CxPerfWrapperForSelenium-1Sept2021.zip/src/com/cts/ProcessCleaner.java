package com.cts;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ProcessCleaner {

	public static void clearChromeDriver() {
		try {
			Runtime.getRuntime().exec("taskkill /im chromedriver.exe /f");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Cleared all chromedriver.exe processes");
	}
	
	public static void clearChromeProcesses() {
		try {
			Runtime.getRuntime().exec("taskkill /im chrome.exe /f");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Cleared all chrome.exe");
	}
	
	public static void clearTempScreenshots() {
		/*String[] command = new String[3];
        command[0] = "cmd";
        command[1] = "/c";
        command[2] = "cd %temp% && del screenshot*.* & del *.tmp & del jansi*.dll";

        
		Process p=null;
		BufferedReader reader=null;
		String line = null;
		try {
			p = Runtime.getRuntime().exec(command);
			reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
	        line = reader.readLine();
	        while (line != null) {
	            System.out.println(line);
	            line = reader.readLine();
	        }
	        System.out.println("Cleared all screenshots");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(p!=null)
				p.destroy();
			if(reader!=null) {
				try {
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				
		}*/
		

	}
	
	public static void clearScopeDirs() {
		
		/*String[] command = new String[3];
        command[0] = "cmd";
        command[1] = "/c";
        command[2] = "cd %temp% && for /D %f in (scoped*) do rmdir %f /Q /S";

        
		Process p=null;
		BufferedReader reader=null;
		String line = null;
		try {
			p = Runtime.getRuntime().exec(command);
			reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
	        line = reader.readLine();
	        while (line != null) {
	            System.out.println(line);
	            line = reader.readLine();
	        }
	        System.out.println("Cleared all scopedirs");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(p!=null)
				p.destroy();
			if(reader!=null) {
				try {
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				
		}*/

	}
}
