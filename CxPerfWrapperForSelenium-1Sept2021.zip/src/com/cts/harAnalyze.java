package com.cts;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class harAnalyze {
	public static String CreateHar(String folderpath) throws InterruptedException {
		JSONObject profiling = new JSONObject();
		List<String> filelist = new ArrayList<String>();
		

		JSONParser jsonparser = new JSONParser();

		try {
			Object obj = jsonparser.parse(new FileReader(folderpath));

			JSONObject jsonobject = (JSONObject) obj;
			JSONObject log = (JSONObject) jsonobject.get("log");
			JSONArray entries = (JSONArray) log.get("entries");
			//System.out.println(entries.size());

			int script = 0;
			int image = 0;
			int html = 0;
			int css = 0;
			int font = 0;
			int other = 0;
			long temp = 0;
			long tempsize = 0;
			int xhr = 0;
			int video = 0;
			for (int i = 0; i < entries.size(); i++)

			{

				JSONObject entriesget = (JSONObject) entries.get(i);
				// System.out.println("response" +response);
				JSONObject response = (JSONObject) entriesget.get("response");
				JSONObject request = (JSONObject) entriesget.get("request");
				long transfersize=(long) response.get("bodySize");
				tempsize=tempsize+transfersize;
				JSONObject content = (JSONObject) response.get("content");
				if (content != null) {
					String type = (String) content.get("mimeType");
					// System.out.println(type);
					long size = (long) content.get("size");
					temp = temp + size;

					if (type.contains("javascript") || type.contains("js")) {
						script++;
					}

					else if (type.contains("image")) {
						image++;
					}

					else if ((type.contains("html") || (type.contains("text/plain")) || (type.contains("text/html")))) {
						html++;
					} else if (type.contains("css")) {
						css++;
					} else if ((type.contains("font")) || (type.contains("woff2"))
							|| (type.contains("application/octet-stream"))) {
						font++;
					} else if (type.contains("json")) {
						xhr++;
					} else if (type.contains("video")) {
						video++;
					}

					else {

						other++;
					}

				}

			}
			if (script != 0)
				profiling.put("javascript", script);
			profiling.put("image", image);
			profiling.put("html", html);
			profiling.put("css", css);
			profiling.put("font", font);
			profiling.put("other", other);
			profiling.put("xhr", xhr);
			profiling.put("pagesize", tempsize);
			profiling.put("nwrequest", entries.size());
			//profiling.put("runtype", runtype);

//			System.out.println("script" + script);
//			System.out.println("image" + image);
//			System.out.println("html" + html);
//			System.out.println("css" + css);
//			System.out.println("font" + font);
//			System.out.println("xhr" + xhr);
//			System.out.println("other" + other);
//			System.out.println("pagesize" + tempsize);
//			System.out.println("nwrequest" + entries.size());
//			System.out.println("tempsize************" + tempsize);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return profiling.toJSONString();

	}
}
