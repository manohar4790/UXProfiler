package com.cts;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.bind.ParseConversionEvent;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
//import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cts.TransactionWrapper;
//import com.mongodb.MongoClient;
//import com.mongodb.MongoClientURI;
//import com.mongodb.client.MongoCollection;
//import com.mongodb.client.MongoCursor;
//import com.mongodb.client.MongoDatabase;
import com.google.gson.JsonObject;

import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.proxy.CaptureType;

public class SeleniumScriptExecutorForCxPerf {
	private static TransactionWrapper myTransactionWrapper;
	private static String applicationName;
	private static String serverUrlPrefix;
	private static long standardThinkTime;
	private static String region;
	private static String userDataProfileLocation;
	private static String chromeDriverPath;
	private static String screenshotPath;
	private static String jwtToken;
	//private static SeleniumLogger mySeleniumLogger;

	private static String ReportFolder;
	private static String resultfolder;
	private static String customerId;
	private static String runId;
	
	static JSONArray tranDetails = new JSONArray();
	static boolean slachk =true;
	static boolean errchk =false;
	static HashMap<String ,JSONArray> iterDetails = new HashMap<String ,JSONArray>();
	static HashMap<String ,ArrayList<Integer>> timeanaly = new HashMap<String ,ArrayList<Integer>>();
	BrowserMobProxy seleproxy;
	JSONObject seleot;
	private static String itrfile;
	
	public SeleniumScriptExecutorForCxPerf(String Token) {
		 iterDetails = new HashMap<String ,JSONArray>();
		 timeanaly = new HashMap<String ,ArrayList<Integer>>();
		 tranDetails = new JSONArray();
		 slachk =true;
		 errchk =false;
//		Properties prop = new Properties();
//		InputStream input = null;
//		try {
//			input = new FileInputStream("config.properties");
//			// load a properties file
//			prop.load(input);
//			serverUrlPrefix = prop.getProperty("ServerURLPrefix");
//			standardThinkTime = Long.parseLong(prop.getProperty("standardThinkTime"));
//			region = prop.getProperty("Region");
//			userDataProfileLocation = prop.getProperty("UserDataProfileLocation");
//			chromeDriverPath = prop.getProperty("ChromeDriverPath");
//			screenshotPath = prop.getProperty("screenshotPath");
//			jwtToken = Token;
//			ReportFolder = prop.getProperty("ReportFolder");
//			File result = new File(ReportFolder+File.separator+"Result"+System.currentTimeMillis());
//			result.mkdir();
//			resultfolder = result.getAbsolutePath();
//			System.out.println(resultfolder);
//		} catch (IOException ex) {
//			ex.printStackTrace();
//		} finally {
//			if (input != null) {
//				try {
//					input.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//		System.out.println("-------  ScriptExecutor ---- Initialized variables --------");
//		System.out.println("serverUrlPrefix : " + serverUrlPrefix);
//		System.out.println("Region : " + region);
//		System.out.println("userDataProfileLocation : " + userDataProfileLocation);
//		System.out.println("chromeDriverPath : " + chromeDriverPath);
//		System.out.println("screenshotPath : " + screenshotPath);

	}
	public void StartTransactionForSelenium(String Transactionname)
	{
		myTransactionWrapper.startTransactionCxPerf(Transactionname);
	}
	
	public void EndTransactionForPass(String Transactionname,int sla,ChromeDriver driver)
	{
		int itr =1;
		JSONObject iterdata = myTransactionWrapper.endTransactionCxPerf(Transactionname, "PASS", sla, driver,itrfile,itr,"CLICK","sample");
		//sc.screenShot(driver, myDoc.getString("transactionName"), esResponse);////
		try {
			iterdata.put("iterationnum", itr);
		
		iterdata.put("itrstatus", "PASS");
		
		if(iterdata.getBoolean("slastatus")==false)
		{
			slachk = false;
		}
		
		if(iterDetails.containsKey(Transactionname))
		{
			JSONArray tmp = iterDetails.get(Transactionname);
			tmp.put(iterdata);
			iterDetails.remove(Transactionname);
			iterDetails.put(Transactionname, tmp);
		}
		else
		{
			JSONArray tmp = new JSONArray();
			tmp.put(iterdata);
			iterDetails.put(Transactionname, tmp);
		}
		
		if(itr==1)
		{
			JSONObject trandata = new JSONObject();
			trandata.put("transactionName", Transactionname);
			trandata.put("sla", sla);
			trandata.put("URL", Transactionname);
			trandata.put("firstUser", iterdata.get("LoadTime"));
			tranDetails.put(trandata);
		}
		
		if(timeanaly.containsKey(Transactionname))
		{
			ArrayList<Integer> resptime = timeanaly.get(Transactionname);
			resptime.add(iterdata.getInt("LoadTime"));
			timeanaly.remove(Transactionname);
			timeanaly.put(Transactionname, resptime);
		}
		else
		{
			ArrayList<Integer> resptime = new ArrayList<Integer>();
//			/iterdata
			resptime.add(iterdata.getInt("LoadTime"));
			timeanaly.put(Transactionname, resptime);
		}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Proxy initializeSelenium(JSONObject scriptDoc)
	{
		seleot = new JSONObject();
		myTransactionWrapper = new TransactionWrapper(applicationName, region, serverUrlPrefix);
		Proxy seleniumProxy =null;
		try {
		System.out.println("JSON from Queue : " + scriptDoc);
		serverUrlPrefix= (String) scriptDoc.getString("serverUrlPrefix");
		ReportFolder = (String) scriptDoc.getString("reportFolder")+"\\\\";
		
		File result = new File(ReportFolder+File.separator+"Result"+System.currentTimeMillis());
		result.mkdir();
		resultfolder = result.getAbsolutePath();
		System.out.println("resultfolder : "+resultfolder);
		JSONObject tempObj = (JSONObject) scriptDoc.get("customerid");
		this.customerId = tempObj.getString("$oid");
		//this.customerId = (String) scriptDoc.getString("customerid");
		tempObj = (JSONObject) scriptDoc.get("Runid");
		this.runId=tempObj.getString("$oid");
		//this.runId = (String) scriptDoc.getString("Runid");
		JSONObject ot = new JSONObject();
		seleot.put("customerId", this.customerId);	
		tempObj = (JSONObject) scriptDoc.get("appid");
		seleot.put("applicationId",tempObj.getString("$oid"));
		//ot.put("applicationId",(String) scriptDoc.getString("appid"));
		tempObj = (JSONObject) scriptDoc.get("scriptid");
		seleot.put("scriptId",tempObj.getString("$oid"));
		//ot.put("scriptId",(String) scriptDoc.getString("scriptid"));
		//int noi = (int) scriptDoc.get("no_of_iteration");
		seleot.put("no_of_iteration", 1);
		//String CacheSettings = (String) scriptDoc.get("CacheSetting");
		seleot.put("CacheSetting", "WithCache");
		seleot.put("regions", (String) scriptDoc.get("regions"));
		seleot.put("scripttype","Selenium");
		seleot.put("scriptname",scriptDoc.get("scriptname"));
		Calendar now = Calendar.getInstance();
		seleot.put("start_time", now.getTime());
		seleot.put("customerName", (String) scriptDoc.get("customerName"));
		seleot.put("applicationName", (String) scriptDoc.get("applicationName"));
		
		//String platform = (String) scriptDoc.get("Platform");
		seleot.put("platform", "Desktop");
		seleot.put("Runid",this.runId);
		
		File iterationfld = new File(resultfolder+File.separator+"Zip");
		iterationfld.mkdir();
		seleproxy = myTransactionWrapper.getProxy();
		itrfile = iterationfld.getAbsolutePath();
		 seleniumProxy = ClientUtil.createSeleniumProxy(seleproxy); 
		 seleproxy.setHarCaptureTypes(CaptureType.getAllContentCaptureTypes());
		 seleproxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT, CaptureType.RESPONSE_HEADERS);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return seleniumProxy;
	}
	
	public void stopcxCollector() throws JSONException
	{
		seleproxy.stop();
		JSONArray finaltran = new JSONArray();
		for(int k=0;k<tranDetails.length();k++)
		{
			JSONObject temp = tranDetails.getJSONObject(k);
			String tname = temp.getString("transactionName");
			ArrayList<Integer> rsptime = timeanaly.get(tname);
			//rsptime.ise
			if(rsptime!=null)
			{
			 Collections.sort(rsptime); 
			 int index = (int) Math.round((95*rsptime.size()/100+0.5));
			 temp.put("_95_percentile", rsptime.get(index-1));
			 int sum=0;
			 for(int l =0;l<rsptime.size();l++)
			 {
				 sum =sum+rsptime.get(l);
			 }
			 float avg = sum/rsptime.size();
			 String formattedString = String.format("%.02f", avg);
			 temp.put("Avg_RT", Float.parseFloat(formattedString));
			 temp.put("Iterations", iterDetails.get(tname));
			}
			else
			{
				temp.put("_95_percentile", "NA");
				temp.put("Avg_RT", "NA");
				 temp.put("Iterations", iterDetails.get(tname));
			}
			 finaltran.put(temp);
		}
		seleot.put("Transactions", finaltran);
		Calendar now1 = Calendar.getInstance();
		seleot.put("end_time", now1.getTime());
		if(slachk==true&&errchk==false)
		{
			seleot.put("slastatus", true);
		}
		else{
			seleot.put("slastatus", false);
		}
		
		if(errchk==true)
		{
			seleot.put("status", "Completed with error");
		}
		else
		{
			seleot.put("status", "Completed");
		}
		//System.out.println(seleot);
try {
			
			FileWriter writerperffile = new FileWriter(itrfile+File.separator+"rundetails.json");
			writerperffile.write(seleot.toString());
			writerperffile.flush();
			writerperffile.close();
			seleot.put("ResultZipPath",resultfolder+File.separator+"Zipped.zip");
			pack(itrfile,resultfolder+File.separator+"Zipped.zip");
			System.out.println("ReportFolder"+this.ReportFolder+"resultfolder"+this.resultfolder);
			
			// postdatatonode
			
			CloseableHttpClient httpClient = HttpClientBuilder.create().build();
//			 String myJSON = "";
//			 String esResponse="";
//			 JSONObject jsonObj = new JSONObject();
//				jsonObj.put("name", "jana");
//				jsonObj.put("age", 65);
			 
			try {
				//myJSON= "{"+"\"resultfolder\": \" "+this.resultfolder+"\"}";
				System.out.println("this.customerId : "+this.customerId+" this.runId : "+this.runId);
				String myURL = this.serverUrlPrefix + "/cxperf/seleniumAPI/insertNewSample";
				HttpPost request = new HttpPost(myURL);
				String zipFilePath=this.resultfolder+File.separator+"Zipped.zip";
				File zipFile=new File(zipFilePath);
				MultipartEntityBuilder  mpEntity=MultipartEntityBuilder.create();
				ContentBody cbFile = new FileBody(zipFile);
		        mpEntity.addPart("zippedFile", cbFile);
		        mpEntity.addTextBody("customerID",this.customerId);
		        mpEntity.addTextBody("runId",this.runId);
		        HttpEntity builedEntity = mpEntity.build();
				request.setEntity(builedEntity);
				HttpResponse httpResponse= httpClient.execute(request);
				System.out.println("---- Response after POST : " + httpResponse.toString());
				// handle response here...

				BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

				String inputLine;
				StringBuffer responseText = new StringBuffer();

				while ((inputLine = reader.readLine()) != null) {
					responseText.append(inputLine);
				}
				reader.close();

				System.out.println("----- Response from Node : "+responseText.toString());
				
			} catch (Exception ex) {
				System.out.println(ex);
				ex.printStackTrace();

			} finally {
				try {
					httpClient.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void runCustomSelenium(JSONObject scriptDoc) throws InterruptedException, JSONException {
		
		System.out.println("JSON from Queue : " + scriptDoc);
		JSONObject tempObj = (JSONObject) scriptDoc.get("customerid");
		this.customerId = tempObj.getString("$oid");
		tempObj = (JSONObject) scriptDoc.get("Runid");
		this.runId=tempObj.getString("$oid");
		JSONObject ot = new JSONObject();
		ot.put("customerId", this.customerId);	
		tempObj = (JSONObject) scriptDoc.get("appid");
		ot.put("applicationId",tempObj.getString("$oid"));
		tempObj = (JSONObject) scriptDoc.get("scriptid");
		ot.put("scriptId",tempObj.getString("$oid"));
		int noi = (int) scriptDoc.get("no_of_iteration");
		ot.put("no_of_iteration", noi);
		String CacheSettings = (String) scriptDoc.get("CacheSetting");
		ot.put("CacheSetting", CacheSettings);
		ot.put("regions", (String) scriptDoc.get("regions"));
		ot.put("scripttype","uidesign");
		ot.put("scriptname",scriptDoc.get("scriptname"));
		Calendar now = Calendar.getInstance();
		ot.put("start_time", now.getTime());
		ot.put("customerName", (String) scriptDoc.get("customerName"));
		ot.put("applicationName", (String) scriptDoc.get("applicationName"));
		
		String platform = (String) scriptDoc.get("Platform");
		ot.put("platform", "Desktop");
		ot.put("Runid",this.runId);

		JSONArray transaction = scriptDoc.getJSONArray("transaction");// transaction Array
		
		
		applicationName = scriptDoc.getString("applicationName");
		/*JSONObject tempObj = (JSONObject) scriptDoc.get("customerid");
		String customerID = tempObj.getString("$oid");
		tempObj = (JSONObject) scriptDoc.get("appid");
		String applicationID = tempObj.getString("$oid");
		//SeleniumScreenShot sc = new SeleniumScreenShot(applicationName, region, screenshotPath, serverUrlPrefix,
				//jwtToken, customerID, applicationID);

		mySeleniumLogger  = new SeleniumLogger(region, serverUrlPrefix, jwtToken);*/
		// if(args!=null && args.length>0)
		// region = args[0];

		System.setProperty("webdriver.chrome.driver", chromeDriverPath);
		//System.setProperty("webdriver.chrome.driver", chromeDriverPath);
		System.out.println("-------- STARTING MEASUREMENTS ---------- ");
		System.out.println("Region : " + region);
		System.out.println("Chrome Driver location : " + chromeDriverPath);
		System.out.println("User data location : " + userDataProfileLocation);
		//System.out.println("transaction : " + transaction);
		//System.out.println("----------------------------------------- ");

		//REQUIRED ONLY for Cognizant machines
		//InetSocketAddress myCognizantProxyAddress = new InetSocketAddress("proxy.cognizant.com", 6050);
		//myTransactionWrapper = new TransactionWrapper(applicationName, region, serverUrlPrefix, myCognizantProxyAddress);
		//int noi =1;
		
		File iterationfld = new File(resultfolder+File.separator+"Zip");
		iterationfld.mkdir();
		
		ChromeDriver driver = null;
		WebDriverWait wait=null;
		myTransactionWrapper = new TransactionWrapper(applicationName, region, serverUrlPrefix);
		
		BrowserMobProxy proxy = myTransactionWrapper.getProxy();
		
		for(int j=0;j<noi;j++)
		{
		
		boolean errflag = false;
		boolean cachechk;
		if(CacheSettings.equals("WithCache"))
		{
			cachechk = true;
		}
		else
		{
			cachechk = false;
		}
		
 //File f2 = new File(resultfolder+File.separator+)
		
		if(j==0||cachechk==false)
		{
			try {
				Runtime.getRuntime().exec("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 8");
				Thread.sleep(5000);
				//System.out.println("Clearcavh complete");
				// Process clearCache =
				// Runtime.getRuntime().exec("C:\\selenium-java-2.43.0\\ClearCacheLite.bat");
				// clearCache.waitFor();
			} catch (Exception e) {
				System.out.println("Failed to clear cache");
			}
		 Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy); 
		 proxy.setHarCaptureTypes(CaptureType.getAllContentCaptureTypes());
			proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT, CaptureType.RESPONSE_HEADERS);
		 /*try { 
			 String hostIp = Inet4Address.getLocalHost().getHostAddress();
			 seleniumProxy.setHttpProxy(hostIp + ":" + proxy.getPort());
			 seleniumProxy.setSslProxy(hostIp + ":" + proxy.getPort());
			 //seleniumProxy.setAutodetect(false);
		 } catch (UnknownHostException e) { 
			 e.printStackTrace(); 
			 // System.exit(0); }
		 }catch(Exception ex) {
			 ex.printStackTrace();
		 }*/
		 
		 ////*[@id="clearBrowsingDataConfirm"]
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		/*capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
		capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
		capabilities.setCapability(CapabilityType.SUPPORTS_APPLICATION_CACHE, true);
		capabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);*/
		
		capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
		capabilities.setCapability("acceptInsecureCerts", true);
		
		capabilities.setJavascriptEnabled(true);
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
		ChromeDriverService service = new ChromeDriverService.Builder()
				.usingDriverExecutable(new File(chromeDriverPath)).usingAnyFreePort().build();
		
		
		ChromeOptions options = new ChromeOptions();
		
if(platform.equals("Mobile"))
{
		 Map<String, Object> deviceMetrics = new HashMap<>();
			deviceMetrics.put("width", 360);
			deviceMetrics.put("height", 640);
			deviceMetrics.put("pixelRatio", 3.0);


			Map<String, Object> mobileEmulation = new HashMap<>();
			mobileEmulation.put("deviceMetrics", deviceMetrics);
			mobileEmulation.put("userAgent", "Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 5 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19");
			options.setExperimentalOption("mobileEmulation", mobileEmulation);
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
}	
		//List<String> chromeArguments = new ArrayList<String>(); 
		//chromeArguments.add("--start-maximized");
		//chromeArguments.add("--start-fullscreen");
		//options.addArguments(chromeArguments);
		
		/*if (userDataProfileLocation != null && !userDataProfileLocation.equals("")) {
			System.out.println("Setting user data dir : " + userDataProfileLocation);
			options.addArguments("user-data-dir=" + userDataProfileLocation);
		}*/
			
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		//options.merge(capabilities);
		
		 driver = new ChromeDriver(service, capabilities);
		//driver.manage().window().maximize();
		//WebDriverWait wait = new WebDriverWait(driver, 300);
		wait = new WebDriverWait(driver, 30);
		
		 //driver.get("chrome://settings/clearBrowserData");
	       // Thread.sleep(20000);
		
	       // driver.switchTo().activeElement();
	        //driver.findElement(By.cssSelector("* /deep/ #clearBrowsingDataConfirm")).click();
	        //Thread.sleep(5000);
	        
	       // driver.get
		//<cr-button id="clearBrowsingDataConfirm" class="action-button" aria-disabled="false" role="button" tabindex="0">
        
		//driver.findElementByXPath("//*[@id=\"clearBrowsingDataConfirm\"]").click();
		//driver.sendKeys(Keys.ENTER);
		}
		/*
		 * MongoClientURI connectionString = new
		 * MongoClientURI("mongodb://localhost:27017"); MongoClient mongoClient = new
		 * MongoClient(connectionString);
		 */
//		 MongoDatabase database = mongoClient.getDatabase("scheduling_table");
//		 MongoCollection<Document> collection = database.getCollection("data");

		try {

			for (int i = 0; i < transaction.length(); i++) {
				
				//proxy.newHar();
				JSONObject eachTransaction = transaction.getJSONObject(i);
				if(j==0)
				{
					JSONObject tranobj = new JSONObject();
					String TranName = (String) eachTransaction.get("transactionName");
					tranobj.put("transactionName", TranName);
					tranobj.put("sla", eachTransaction.get("sla"));
					tranobj.put("URL", eachTransaction.get("navigate"));
					//transactionName
					//eachTransaction.get("eachTransaction");
				}
				if (eachTransaction.has("methods")) {
					if (eachTransaction.getString("methods").equalsIgnoreCase("Get")) {
						//System.out.println("Navigating to : " + eachTransaction.toString());
						getFunction(driver, eachTransaction, wait,iterationfld.getAbsolutePath(),(j+1));
					} else if (eachTransaction.getString("methods").equalsIgnoreCase("Click")) {
						//System.out.println("else if block");
						clickFunction(driver, eachTransaction, wait,iterationfld.getAbsolutePath(),(j+1));
					} else {
						//System.out.println("else block");
					}
				}
				myTransactionWrapper.pause(standardThinkTime);
				proxy.endHar();
			}
		} catch (Exception ex) {
			System.out.println("Exception");
			errflag=true;
			ex.printStackTrace();
		} finally {
			System.out.println("finally block");
			// cursor.close();
			if(cachechk==false)
			{
			driver.close();
			driver.quit();
			ProcessCleaner.clearChromeDriver();
			ProcessCleaner.clearChromeProcesses();
			ProcessCleaner.clearScopeDirs();
			ProcessCleaner.clearTempScreenshots();
			}
			
		}
		}
		
		if(CacheSettings.equals("WithCache"))
		{
			driver.close();
			driver.quit();
		}
			ProcessCleaner.clearChromeDriver();
			ProcessCleaner.clearChromeProcesses();
			ProcessCleaner.clearScopeDirs();
			ProcessCleaner.clearTempScreenshots();
		proxy.stop();
		
		//tranDetails
		//iterDetails
		//timeanaly
		JSONArray finaltran = new JSONArray();
		for(int k=0;k<tranDetails.length();k++)
		{
			JSONObject temp = tranDetails.getJSONObject(k);
			String tname = temp.getString("transactionName");
			ArrayList<Integer> rsptime = timeanaly.get(tname);
			 Collections.sort(rsptime); 
			 int index = (int) Math.round((95*rsptime.size()/100+0.5));
			 temp.put("_95_percentile", rsptime.get(index-1));
			 int sum=0;
			 for(int l =0;l<rsptime.size();l++)
			 {
				 sum =sum+rsptime.get(l);
			 }
			 float avg = sum/rsptime.size();
			 String formattedString = String.format("%.02f", avg);
			 temp.put("Avg_RT", Float.parseFloat(formattedString));
			 temp.put("Iterations", iterDetails.get(tname));
			 finaltran.put(temp);
		}
		ot.put("Transactions", finaltran);
		Calendar now1 = Calendar.getInstance();
		ot.put("end_time", now1.getTime());
		if(slachk==true)
		{
			ot.put("slastatus", "PASS");
		}
		else{
			ot.put("slastatus", "FAIL");
		}
		
		if(errchk==true)
		{
			ot.put("status", "Completed with error");
		}
		else
		{
			ot.put("status", "Completed");
		}
		//System.out.println(ot);
		
		try {
			
			FileWriter writerperffile = new FileWriter(iterationfld+File.separator+"rundetails.json");
			writerperffile.write(ot.toString());
			writerperffile.flush();
			writerperffile.close();
			ot.put("ResultZipPath",resultfolder+File.separator+"Zipped.zip");
			pack(iterationfld.getAbsolutePath(),resultfolder+File.separator+"Zipped.zip");
			//System.out.println("ReportFolder"+this.ReportFolder+"resultfolder"+this.resultfolder);
			
			// postdatatonode
			
			CloseableHttpClient httpClient = HttpClientBuilder.create().build();
//			 String myJSON = "";
//			 String esResponse="";
//			 JSONObject jsonObj = new JSONObject();
//				jsonObj.put("name", "jana");
//				jsonObj.put("age", 65);
			 
			try {
				//myJSON= "{"+"\"resultfolder\": \" "+this.resultfolder+"\"}";
				//System.out.println("this.customerId : "+this.customerId+" this.runId : "+this.runId);
				String myURL = this.serverUrlPrefix + "/cxperf/seleniumAPI/insertNewSample";
				HttpPost request = new HttpPost(myURL);
				String zipFilePath=this.resultfolder+File.separator+"Zipped.zip";
				File zipFile=new File(zipFilePath);
				MultipartEntityBuilder  mpEntity=MultipartEntityBuilder.create();
				ContentBody cbFile = new FileBody(zipFile);
		        mpEntity.addPart("zippedFile", cbFile);
		        mpEntity.addTextBody("customerID",this.customerId);
		        mpEntity.addTextBody("runId",this.runId);
		        HttpEntity builedEntity = mpEntity.build();
				request.setEntity(builedEntity);
				HttpResponse httpResponse= httpClient.execute(request);
				System.out.println("---- Response after POST : " + httpResponse.toString());
				// handle response here...

				BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

				String inputLine;
				StringBuffer responseText = new StringBuffer();

				while ((inputLine = reader.readLine()) != null) {
					responseText.append(inputLine);
				}
				reader.close();

				System.out.println("----- Response from Node : "+responseText.toString());
				
			} catch (Exception ex) {
				System.out.println(ex);
				ex.printStackTrace();

			} finally {
				try {
					httpClient.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		}
		/*
		 * try { while (cursor.hasNext()) { //
		 * System.out.println(cursor.next().toJson()); Document myDoc = cursor.next();
		 * System.out.println(myDoc.toJson()); System.out.println();
		 * if(myDoc.getString("method").equalsIgnoreCase("get")){
		 * System.out.println("if block"); getFunction(driver,myDoc,wait,sc); } else
		 * if(myDoc.getString("method").equalsIgnoreCase("click")){
		 * System.out.println("else if block"); clickFunction(driver,myDoc,wait,sc); }
		 * else{ System.out.println("else block"); } Thread.sleep(2000); } } finally {
		 * System.out.println("finally block"); cursor.close(); driver.close();
		 * //System.exit(0); }
		 */
	
//SeleniumScreenShot sc
	private static void clickFunction(ChromeDriver driver, JSONObject myDoc, WebDriverWait wait, String filepath, int itr)
			throws NumberFormatException, JSONException {
		
		System.out.println("inside click function");
//		long sla=1000;

//		long sla= Long.parseLong(myDoc.getString("sla"),10);
		long sla = Long.parseLong((myDoc.get("sla").toString()));
		String tranname = myDoc.getString("transactionName");
		String navigateURL = myDoc.getString("navigate");
		//System.out.println(" Sla : " + sla);
		// WebDriverWait wait = new WebDriverWait(driver, 10);
		String esResponse= null;
//		JSONObject esResponse= null;
		JSONObject esResponseObject  = null;
		//"_id":"0jCcnWgBf_bMLnxe_BRh"
		String transcation_id = null;
		try {
			myTransactionWrapper.startTransactionCxPerf(myDoc.getString("transactionName"));
			driver.findElement(By.xpath(myDoc.getString("navigate"))).click();
			System.out.println("after clicking");
			String xpathForValidation = myDoc.getString("xpath");
			if(xpathForValidation!=null && !xpathForValidation.trim().equals("")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpathForValidation)));
				System.out.println("after wait until");
			}
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(myDoc.getString("xpath"))));

			JSONObject iterdata = myTransactionWrapper.endTransactionCxPerf(myDoc.getString("transactionName"), "PASS", sla, driver,filepath,itr,"CLICK",navigateURL);
			//sc.screenShot(driver, myDoc.getString("transactionName"), esResponse);////
			iterdata.put("iterationnum", itr);
			iterdata.put("itrstatus", "PASS");
			
			if(iterdata.getBoolean("slastatus")==false)
			{
				slachk = false;
			}
			
			if(iterDetails.containsKey(tranname))
			{
				JSONArray tmp = iterDetails.get(tranname);
				tmp.put(iterdata);
				iterDetails.remove(tranname);
				iterDetails.put(tranname, tmp);
			}
			else
			{
				JSONArray tmp = new JSONArray();
				tmp.put(iterdata);
				iterDetails.put(tranname, tmp);
			}
			
			if(itr==1)
			{
				JSONObject trandata = new JSONObject();
				trandata.put("transactionName", tranname);
				trandata.put("sla", sla);
				trandata.put("URL", navigateURL);
				trandata.put("firstUser", iterdata.get("LoadTime"));
				tranDetails.put(trandata);
			}
			
			if(timeanaly.containsKey(tranname))
			{
				ArrayList<Integer> resptime = timeanaly.get(tranname);
				resptime.add(Integer.parseInt((String)iterdata.get("LoadTime")));
				timeanaly.remove(tranname);
				timeanaly.put(tranname, resptime);
			}
			else
			{
				ArrayList<Integer> resptime = new ArrayList<Integer>();
				resptime.add(Integer.parseInt((String)iterdata.get("LoadTime")));
				timeanaly.put(tranname, resptime);
			}
			//System.out.println("esResponse "+esResponse);
			//"_id":"0jCcnWgBf_bMLnxe_BRh"
			//esResponseObject  = new JSONObject(esResponse);
			//transcation_id = esResponseObject.getString("_id");
			//mySeleniumLogger.logPost(transcation_id, "PASS", new Date().toString());
		} catch (TimeoutException e) {
			errchk =true;
			JSONObject iterdata = myTransactionWrapper.endTransactionCxPerf(myDoc.getString("transactionName"), "FAIL", sla, driver,filepath,itr,"CLICK",navigateURL);
			iterdata.put("iterationnum", itr);
			iterdata.put("itrstatus", "FAIL");
			slachk = false;
			if(iterDetails.containsKey(tranname))
			{
				JSONArray tmp = iterDetails.get(tranname);
				tmp.put(iterdata);
				iterDetails.remove(tranname);
				iterDetails.put(tranname, tmp);
			}
			else
			{
				JSONArray tmp = new JSONArray();
				tmp.put(iterdata);
				iterDetails.put(tranname, tmp);
			}
			
			if(itr==1)
			{
				JSONObject trandata = new JSONObject();
				trandata.put("transactionName", tranname);
				trandata.put("sla", sla);
				trandata.put("URL", navigateURL);
				trandata.put("firstUser", "NA");
				tranDetails.put(trandata);
			}
			e.printStackTrace();
		} catch (NoSuchElementException e) {
			errchk =true;
			JSONObject iterdata = myTransactionWrapper.endTransactionCxPerf(myDoc.getString("transactionName"), "FAIL", sla, driver,filepath,itr,"CLICK",navigateURL);
			iterdata.put("iterationnum", itr);
			iterdata.put("itrstatus", "FAIL");
			slachk = false;
			if(iterDetails.containsKey(tranname))
			{
				JSONArray tmp = iterDetails.get(tranname);
				tmp.put(iterdata);
				iterDetails.remove(tranname);
				iterDetails.put(tranname, tmp);
			}
			else
			{
				JSONArray tmp = new JSONArray();
				tmp.put(iterdata);
				iterDetails.put(tranname, tmp);
			}
			
			if(itr==1)
			{
				JSONObject trandata = new JSONObject();
				trandata.put("transactionName", tranname);
				trandata.put("sla", sla);
				trandata.put("URL", navigateURL);
				trandata.put("firstUser", "NA");
				tranDetails.put(trandata);
			}
			e.printStackTrace();
		} catch (Exception e) {
			errchk =true;
			JSONObject iterdata = new JSONObject();
			iterdata.put("harPath", "");
			iterdata.put("logjson", new JSONObject());
			iterdata.put("performancejson", new JSONObject());
			iterdata.put("recommendation", new JSONArray());
			iterdata.put("TotalRequestsCount", 0);
		//	trandetails.put("iterationnum", itr);
			iterdata.put("slastatus", false);
			iterdata.put("TotalTransactionSize", 0);
			iterdata.put("LoadTime", "NA");
			iterdata.put("itrstatus", "FAIL");
			iterdata.put("iterationnum", itr);
			iterdata.put("itrstatus", "FAIL");
			iterdata.put("responsetime", "NA");
			
			slachk = false;
			if(iterDetails.containsKey(tranname))
			{
				JSONArray tmp = iterDetails.get(tranname);
				tmp.put(iterdata);
				iterDetails.remove(tranname);
				iterDetails.put(tranname, tmp);
			}
			else
			{
				JSONArray tmp = new JSONArray();
				tmp.put(iterdata);
				iterDetails.put(tranname, tmp);
			}
			
			if(itr==1)
			{
				JSONObject trandata = new JSONObject();
				trandata.put("transactionName", tranname);
				trandata.put("sla", sla);
				trandata.put("URL", navigateURL);
				trandata.put("firstUser", "NA");
				tranDetails.put(trandata);
			}
			e.printStackTrace();
		}finally {
			//sc.screenShot(driver, myDoc.getString("transactionName"), esResponse);
//			driver.close();
//			driver.quit();
			myTransactionWrapper.pause(standardThinkTime);
		}

//		myTransactionWrapper.pause(standardThinkTime);
	}
// SeleniumScreenShot sc
	private static void getFunction(ChromeDriver driver, JSONObject myDoc, WebDriverWait wait, String filepath, int itr)
			throws NumberFormatException, JSONException {
		// TODO Auto-generated method stub
		System.out.println("inside getfunction");
		long sla = Long.parseLong((myDoc.get("sla").toString()));
		
		// long sla=myDoc.getLong("sla");
		String tranname = myDoc.getString("transactionName");
		// WebDriverWait wait = new WebDriverWait(driver, 10);
		// long sla=1000;
		//System.out.println(" Sla : " + sla);
		String esResponse= null;
		JSONObject esResponseObject  = null;
		//"_id":"0jCcnWgBf_bMLnxe_BRh"
		String transcation_id = null;
		String navigateURL = myDoc.getString("navigate");
		try {
			myTransactionWrapper.startTransactionCxPerf(myDoc.getString("transactionName"));
			
			System.out.println("-- Navigate to : " + navigateURL);
			driver.get(navigateURL);
			System.out.println("- after navigating");
			String xpathForValidation = myDoc.getString("xpath");
			if(xpathForValidation!=null && !xpathForValidation.trim().equals("")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpathForValidation)));
				System.out.println("after wait until");
			}
			JSONObject iterdata = myTransactionWrapper.endTransactionCxPerf(myDoc.getString("transactionName"), "PASS", sla, driver, filepath,itr,"GET",navigateURL);
			iterdata.put("iterationnum", itr);
			//System.out.println("- return obj+"+iterdata.toString());
			
			if(!iterdata.has("itrstatus"))
			{
			iterdata.put("itrstatus", "PASS");
			
			if(iterdata.getBoolean("slastatus")==false)
			{
				slachk = false;
			}
			 Thread.sleep(20000);
			 
			//System.out.println("Iterationnum"+itr);
			if(iterDetails.containsKey(tranname))
			{
				JSONArray tmp = iterDetails.get(tranname);
				tmp.put(iterdata);
				iterDetails.remove(tranname);
				iterDetails.put(tranname, tmp);
			}
			else
			{
				JSONArray tmp = new JSONArray();
				tmp.put(iterdata);
				iterDetails.put(tranname, tmp);
			}
			
			if(itr==1)
			{
				JSONObject trandata = new JSONObject();
				trandata.put("transactionName", tranname);
				trandata.put("sla", sla);
				trandata.put("URL", navigateURL);
				trandata.put("firstUser", iterdata.get("LoadTime"));
				tranDetails.put(trandata);
			}
			
			if(timeanaly.containsKey(tranname))
			{
				ArrayList<Integer> resptime = timeanaly.get(tranname);
				resptime.add(iterdata.getInt("LoadTime"));
				timeanaly.remove(tranname);
				timeanaly.put(tranname, resptime);
			}
			else
			{
				ArrayList<Integer> resptime = new ArrayList<Integer>();
				resptime.add(iterdata.getInt("LoadTime"));
				timeanaly.put(tranname, resptime);
			}
			}
			else
			{
				errchk =true;
				slachk = false;
				//JSONObject iterdata = myTransactionWrapper.endTransactionCxPerf(myDoc.getString("transactionName"), "FAIL", sla, driver,filepath,itr,"GET",navigateURL);
				iterdata.put("iterationnum", itr);
				iterdata.put("itrstatus", "FAIL");
				if(iterDetails.containsKey(tranname))
				{
					JSONArray tmp = iterDetails.get(tranname);
					tmp.put(iterdata);
					iterDetails.remove(tranname);
					iterDetails.put(tranname, tmp);
				}
				else
				{
					JSONArray tmp = new JSONArray();
					tmp.put(iterdata);
					iterDetails.put(tranname, tmp);
				}
				
				if(itr==1)
				{
					JSONObject trandata = new JSONObject();
					trandata.put("transactionName", tranname);
					trandata.put("sla", sla);
					trandata.put("URL", navigateURL);
					trandata.put("firstUser", "NA");
					tranDetails.put(trandata);
				}
			}
			//if(esResponse==null) {
				//System.err.println("ERROR : esResponse = null, endTransactionEx() returned Null");
			//}else {
				//sc.screenShot(driver, myDoc.getString("transactionName"), esResponse);
				//System.out.println("after endTransaction");

				//esResponseObject  = new JSONObject(esResponse);
				//"_id":"0jCcnWgBf_bMLnxe_BRh"
				//transcation_id = esResponseObject.getString("_id");
				
				//mySeleniumLogger.logPost(transcation_id, "PASS", new Date().toString());
			//}
		} catch (TimeoutException e) {
			errchk =true;
			JSONObject iterdata = myTransactionWrapper.endTransactionCxPerf(myDoc.getString("transactionName"), "FAIL", sla, driver,filepath,itr,"GET",navigateURL);
			iterdata.put("iterationnum", itr);
			iterdata.put("itrstatus", "FAIL");
			if(iterDetails.containsKey(tranname))
			{
				JSONArray tmp = iterDetails.get(tranname);
				tmp.put(iterdata);
				iterDetails.remove(tranname);
				iterDetails.put(tranname, tmp);
			}
			else
			{
				JSONArray tmp = new JSONArray();
				tmp.put(iterdata);
				iterDetails.put(tranname, tmp);
			}
			
			if(itr==1)
			{
				JSONObject trandata = new JSONObject();
				trandata.put("transactionName", tranname);
				trandata.put("sla", sla);
				trandata.put("URL", navigateURL);
				trandata.put("firstUser", "NA");
				tranDetails.put(trandata);
			}
			e.printStackTrace();
		} catch (NoSuchElementException e) {
			errchk =true;
			JSONObject iterdata = myTransactionWrapper.endTransactionCxPerf(myDoc.getString("transactionName"), "FAIL", sla, driver,filepath,itr,"GET",navigateURL);
			iterdata.put("iterationnum", itr);
			iterdata.put("itrstatus", "FAIL");
			if(iterDetails.containsKey(tranname))
			{
				JSONArray tmp = iterDetails.get(tranname);
				tmp.put(iterdata);
				iterDetails.remove(tranname);
				iterDetails.put(tranname, tmp);
			}
			else
			{
				JSONArray tmp = new JSONArray();
				tmp.put(iterdata);
				iterDetails.put(tranname, tmp);
			}
			
			if(itr==1)
			{
				JSONObject trandata = new JSONObject();
				trandata.put("transactionName", tranname);
				trandata.put("sla", sla);
				trandata.put("URL", navigateURL);
				trandata.put("firstUser", "NA");
				tranDetails.put(trandata);
			}
			e.printStackTrace();
		} catch (Exception e) {
			//esResponse = myTransactionWrapper.endTransactionEx(myDoc.getString("transactionName"), "FAIL", sla, driver);
			errchk =true;
			JSONObject iterdata = new JSONObject();
			iterdata.put("harPath", "");
			iterdata.put("logjson", new JSONObject());
			iterdata.put("performancejson", new JSONObject());
			iterdata.put("recommendation", new JSONArray());
			iterdata.put("TotalRequestsCount", 0);
		//	trandetails.put("iterationnum", itr);
			iterdata.put("slastatus", false);
			iterdata.put("TotalTransactionSize", 0);
			iterdata.put("LoadTime", "NA");
			iterdata.put("itrstatus", "FAIL");
			iterdata.put("iterationnum", itr);
			iterdata.put("itrstatus", "FAIL");
			iterdata.put("responsetime", "NA");
			
			if(iterDetails.containsKey(tranname))
			{
				JSONArray tmp = iterDetails.get(tranname);
				tmp.put(iterdata);
				iterDetails.remove(tranname);
				iterDetails.put(tranname, tmp);
			}
			else
			{
				JSONArray tmp = new JSONArray();
				tmp.put(iterdata);
				iterDetails.put(tranname, tmp);
			}
			
			if(itr==1)
			{
				JSONObject trandata = new JSONObject();
				trandata.put("transactionName", tranname);
				trandata.put("sla", sla);
				trandata.put("URL", navigateURL);
				trandata.put("firstUser", "NA");
				tranDetails.put(trandata);
			}
			e.printStackTrace();

			//esResponseObject  = new JSONObject(esResponse);
			//"_id":"0jCcnWgBf_bMLnxe_BRh"
			//transcation_id = esResponseObject.getString("_id");
			
			//mySeleniumLogger.logPost(transcation_id, "FAIL", new Date().toString());
			//mySeleniumLogger.logPost(transcation_id, e.getMessage(), new Date().toString());
		}finally {
			//sc.screenShot(driver, myDoc.getString("transactionName"), esResponse);
		
			myTransactionWrapper.pause(standardThinkTime);
//			driver.close();
//			driver.quit();
		}

//		myTransactionWrapper.pause(standardThinkTime);

	}
	
	
	
	public static void pack(String sourceDirPath, String zipFilePath) throws IOException {
	    Path p = Files.createFile(Paths.get(zipFilePath));
	    Path pp = Paths.get(sourceDirPath);
	    try (ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(p));
	        Stream<Path> paths = Files.walk(pp)) {
	        paths
	          .filter(path -> !Files.isDirectory(path))
	          .forEach(path -> {
	              ZipEntry zipEntry = new ZipEntry(pp.relativize(path).toString());
	              try {
	                  zs.putNextEntry(zipEntry);
	                  Files.copy(path, zs);
	                  zs.closeEntry();
	            } catch (IOException e) {
	                System.err.println(e);
	            }
	          });
	    }
	}
}
