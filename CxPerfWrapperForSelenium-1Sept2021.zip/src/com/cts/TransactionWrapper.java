package com.cts;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.littleshoot.proxy.HttpProxyServer;
import org.littleshoot.proxy.HttpProxyServerBootstrap;
import org.littleshoot.proxy.impl.DefaultHttpProxyServer;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.JsonObject;

import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.core.har.HarEntry;
import net.lightbody.bmp.core.har.HarPage;
import net.lightbody.bmp.mitm.CertificateAndKeySource;
import net.lightbody.bmp.mitm.RootCertificateGenerator;
import net.lightbody.bmp.mitm.TrustSource;
import net.lightbody.bmp.mitm.keys.ECKeyGenerator;
import net.lightbody.bmp.mitm.manager.ImpersonatingMitmManager;
import net.lightbody.bmp.proxy.CaptureType;

public class TransactionWrapper {

	private String applicationName;
	private String connectionString;
	private String region;
	private String serverURLPrefix;
	private StopWatch pageLoad;
	public long lastLoadTime;
	/** For Browser mob proxy **/
	private BrowserMobProxy proxy;

	public TransactionWrapper(String applicationName, String region) {
		this.applicationName = applicationName;
		this.region = region;
	}

	public TransactionWrapper(String applicationName, String region, String serverURLPrefix) {

		System.out.println("JRE : " + System.getProperty("java.home"));
		this.applicationName = applicationName;
		this.region = region;
		this.serverURLPrefix = serverURLPrefix;

		// create a RootCertificateGenerator that generates EC Certificate Authorities;
		// you may also load your
		// own EC certificate and private key using any other CertificateAndKeySource
		// implementation
		// (KeyStoreFileCertificateSource, PemFileCertificateSource, etc.).
		CertificateAndKeySource rootCertificateGenerator = RootCertificateGenerator.builder()
				.keyGenerator(new ECKeyGenerator()).build();

		// tell the ImpersonatingMitmManager to generate EC keys and to use the EC
		// RootCertificateGenerator
		ImpersonatingMitmManager mitmManager = ImpersonatingMitmManager.builder()
				.rootCertificateSource(rootCertificateGenerator).serverKeyGenerator(new ECKeyGenerator()).build();

		// Initialize proxy server (Browser mob proxy)
		// start the proxy
		proxy = new BrowserMobProxyServer();
		// proxy.setMitmManager(mitmManager);
		// proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT,
		// CaptureType.RESPONSE_CONTENT);
		proxy.setTrustAllServers(true);
		proxy.start();
		// proxy.start(0);
		// enable more detailed HAR capture, if desired (see CaptureType for the
		// complete list)
		// proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT,
		// CaptureType.RESPONSE_CONTENT);

	}

	public TransactionWrapper(String applicationName, String region, String serverURLPrefix,
			InetSocketAddress proxySocketAddress) {

		System.out.println("JRE : " + System.getProperty("java.home"));
		this.applicationName = applicationName;
		this.region = region;
		this.serverURLPrefix = serverURLPrefix;

		// create a RootCertificateGenerator that generates EC Certificate Authorities;
		// you may also load your
		// own EC certificate and private key using any other CertificateAndKeySource
		// implementation
		// (KeyStoreFileCertificateSource, PemFileCertificateSource, etc.).
		CertificateAndKeySource rootCertificateGenerator = RootCertificateGenerator.builder()
				.keyGenerator(new ECKeyGenerator()).build();

		// tell the ImpersonatingMitmManager to generate EC keys and to use the EC
		// RootCertificateGenerator
		ImpersonatingMitmManager mitmManager = ImpersonatingMitmManager.builder()
				.rootCertificateSource(rootCertificateGenerator).serverKeyGenerator(new ECKeyGenerator()).build();

		// Initialize proxy server (Browser mob proxy)
		// start the proxy
		proxy = new BrowserMobProxyServer();
		// proxy.setMitmManager(mitmManager);
		// proxy.setHarCaptureTypes(CaptureType.getAllContentCaptureTypes());
		// proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT,
		// CaptureType.RESPONSE_CONTENT, CaptureType.RESPONSE_HEADERS);
		// proxy.setTrustAllServers(true);
		// proxy.setChainedProxy(proxySocketAddress);
		proxy.start();

	}

	public BrowserMobProxy getProxy() {
		return proxy;
	}

	public void startTransaction(String transactionName) {
		pageLoad = new StopWatch();
		// System.out.println("Tx " + transactionName+" start1 : " + (new
		// Date().getTime()));
		pageLoad.start();
		// System.out.println("Tx " + transactionName+" start2 : " + (new
		// Date().getTime()));

	}

	public void startTransactionEx(String transactionName) {
		// create a new HAR with the label "yahoo.com"
		proxy.newHar(transactionName);
		startTransaction(transactionName);
	}

	public void startTransactionCxPerf(String transactionName) {
		// create a new HAR with the label "yahoo.com"
		proxy.newHar(transactionName);
		startTransaction(transactionName);
	}

	public void endTransaction(String transactionName, String status, ChromeDriver driver) {
		long pageLoadTime_ms = 0;
		// System.out.println("Tx " + transactionName+" end1 : " + (new
		// Date().getTime()));
		if (pageLoad != null && pageLoad.isStarted()) {
			pageLoad.stop();
			pageLoadTime_ms = pageLoad.getTime();
		}

		// System.out.println("Tx " + transactionName+" end2 : " + (new
		// Date().getTime()));

		String jsEvents = null;
		if (driver != null) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			jsEvents = getPageStats(js);
		}

		// (new MyInfluxDBClient(dbHost, dbPort)).insertDataToInfluxDB(transactionName,
		// status, region, applicationName, pageLoadTime_Seconds);
		/*
		 * (new MyElasticSearchClient(dbHost,
		 * dbPort)).insertToElasticSearch(transactionName, status, region,
		 * applicationName, pageLoadTime_ms, null, jsEvents); (new
		 * MyInfluxDBClient(dbHost, 8086,
		 * applicationName)).insertDataToInfluxDB(transactionName, status, region,
		 * pageLoadTime_ms);
		 */

	}

	public String endTransactionEx(String transactionName, String status, long sla, ChromeDriver driver) {
		String esResponse = null;

		long pageLoadTime_ms = 0;
		try {
			if (pageLoad != null && pageLoad.isStarted()) {
				pageLoad.stop();
				pageLoadTime_ms = pageLoad.getTime();
			} else {
				System.out.println("ERROR : pageLoad is " + pageLoad);
				return null;
			}

		} catch (Exception Ex) {
			Ex.printStackTrace();
			System.out.println("esResponse in Transaction Wrapper catch block" + esResponse);
			return esResponse;
		}

		// System.out.println("********* Transaction name : " + transactionName + ",
		// E2EResponsetime : " + pageLoadTime_ms);
		Har har = null;

		// Only if response time > SLA, save the HAR file entries in DB

		if (pageLoadTime_ms > sla) {
			if (proxy != null) {
				if (proxy.getHar() != null) {
					har = proxy.getHar();

					// System.out.println("# of HAR file entries : " +
					// har.getLog().getEntries().size());
				} else {
					System.err.println("HAR file is null for : " + transactionName);
				}
			} else {
				System.err.println("Proxy is null : " + transactionName);
			}
		}

		String jsEvents = null;
		if (driver != null) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			try {
				jsEvents = getPageStats(js);
			} catch (Exception ex) {
				jsEvents = "";
			}
		}

		int totalRequestCount = 0;
		int passRequestCount = 0;
		int failRequestCount = 0;
		long totalTransactionSize = 0;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		String dateString = sdf.format(new Date());

		boolean slastatus;
		if (pageLoadTime_ms < sla)
			slastatus = true;
		else
			slastatus = false;

		String myJSON = "{" + "    \"application\" : \"" + applicationName + "\"," + "    \"transaction\" : \""
				+ transactionName + "\"," + "    \"sampleSource\" : \"SeleniumScript\"," + "	 \"sla\"		 : \""
				+ sla + "\"," + "	 \"slastatus\"		 : \"" + slastatus + "\"," + "              \"region\" : \""
				+ region + "\"," + "              \"status\" : \"" + status + "\"," + "    \"responsetime\" : "
				+ pageLoadTime_ms + "," + jsEvents + "," + "    \"post_date\" : \"" + dateString + "\"";

		if (har != null) {
			myJSON = myJSON + ",\"NetworkStatsCalls\" : true";
			// myJSON = myJSON + ", \"NetworkCalls\" : [";
			List<HarPage> harPageList = har.getLog().getPages();
			// System.out.println("# of harPages : " + harPageList.size());
			Iterator<HarPage> myIterator = harPageList.listIterator();

			List<HarEntry> entries = har.getLog().getEntries();
			JSONArray myJsonArray = new JSONArray();
			for (int i = 0; i < entries.size(); i++) {
				HarEntry entry = entries.get(i);
				JSONObject mySimpleJSONObject = new JSONObject();

				try {
					mySimpleJSONObject.put("url", entry.getRequest().getUrl());
					mySimpleJSONObject.put("status", entry.getResponse().getStatus());
					mySimpleJSONObject.put("statustext", entry.getResponse().getStatusText());
					mySimpleJSONObject.put("method", entry.getRequest().getMethod());
					mySimpleJSONObject.put("mimetype",
							entry.getResponse().getContent().getMimeType().replace("\"", "\\\""));
					long loadTime = entry.getTime();
					if (loadTime <= 0) {
						System.err
								.println("Loadtime = " + loadTime + ", excluding URL : " + entry.getRequest().getUrl());
						continue;
						// loadTime=0;
					}
					mySimpleJSONObject.put("loadtime", loadTime);
					mySimpleJSONObject.put("blockedTime", entry.getTimings().getBlocked());
					mySimpleJSONObject.put("connectTime", entry.getTimings().getConnect());
					mySimpleJSONObject.put("dnsTime", entry.getTimings().getDns());
					mySimpleJSONObject.put("receiveTime", entry.getTimings().getReceive());
					mySimpleJSONObject.put("sendTime", entry.getTimings().getSend());
					mySimpleJSONObject.put("sslTime", entry.getTimings().getSsl());
					mySimpleJSONObject.put("waitTime", entry.getTimings().getWait());

					String startTimeString = sdf.format(entry.getStartedDateTime());
					mySimpleJSONObject.put("starttime", startTimeString);

					long responseSize = entry.getResponse().getBodySize() + entry.getRequest().getHeadersSize();
					if (responseSize <= 0) {
						System.err.println("Response size <0, i.e., = " + responseSize + ", excluding URL : "
								+ entry.getRequest().getUrl());
						// responseSize = 0;
						continue;
					}
					mySimpleJSONObject.put("responsesize", responseSize);

					totalRequestCount++;
					totalTransactionSize = totalTransactionSize + responseSize;
				} catch (JSONException e) {
					e.printStackTrace();
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				/*
				 * myJSON = myJSON + "{"; myJSON = myJSON + "\"url\":\"" +
				 * entry.getRequest().getUrl() + "\","; myJSON = myJSON + "\"status\":" +
				 * entry.getResponse().getStatus() + ","; myJSON = myJSON + "\"statustext\":\""
				 * + entry.getResponse().getStatusText() + "\","; myJSON = myJSON +
				 * "\"method\":\"" + entry.getRequest().getMethod() + "\","; myJSON = myJSON +
				 * "\"mimetype\":\"" +
				 * entry.getResponse().getContent().getMimeType().replace("\"", "\\\"") + "\",";
				 * long loadTime = entry.getTime(); if (loadTime < 0) loadTime = 0;
				 * 
				 * myJSON = myJSON + "\"loadtime\":" + loadTime + ","; myJSON = myJSON +
				 * "\"blockedTime\":" + entry.getTimings().getBlocked() + ","; myJSON = myJSON +
				 * "\"connectTime\":" + entry.getTimings().getConnect() + ","; myJSON = myJSON +
				 * "\"dnsTime\":" + entry.getTimings().getDns() + ","; myJSON = myJSON +
				 * "\"receiveTime\":" + entry.getTimings().getReceive() + ","; myJSON = myJSON +
				 * "\"sendTime\":" + entry.getTimings().getSend() + ","; myJSON = myJSON +
				 * "\"sslTime\":" + entry.getTimings().getSsl() + ","; myJSON = myJSON +
				 * "\"waitTime\":" + entry.getTimings().getWait() + ",";
				 * 
				 * String startTimeString = sdf.format(entry.getStartedDateTime()); myJSON =
				 * myJSON + "\"starttime\":\"" + startTimeString + "\","; long responseSize =
				 * entry.getResponse().getBodySize() + entry.getRequest().getHeadersSize(); if
				 * (responseSize < 0) responseSize = 0; myJSON = myJSON + "\"responsesize\":" +
				 * responseSize;
				 * 
				 * myJSON = myJSON + "}"; if (i < entries.size() - 1) myJSON = myJSON + ",";
				 * 
				 * totalRequestCount++; totalTransactionSize = totalTransactionSize +
				 * responseSize;
				 */
				myJsonArray.put(mySimpleJSONObject);
			}
			// myJSON = myJSON + "]";
			myJSON = myJSON + ",\"NetworkCalls\":" + myJsonArray.toString();
		} else {
			myJSON = myJSON + ",\"NetworkStatsCalls\" : false";
		}
		myJSON = myJSON + ",\"TotalRequestsCount\" : " + totalRequestCount + "";
		myJSON = myJSON + ",\"TotalTransactionSize\" : " + totalTransactionSize + "";
		myJSON = myJSON + "}";
		// System.out.println("json : " + myJSON);
		// String myURL = this.serverURLPrefix+"/samplesAPI/insertNewSample";
		String myURL = this.serverURLPrefix + "/seleniumAPI/insertNewSample";
		System.out.println("Before HTTP POST TO : " + myURL);
		// Do HTTP post with this JSON to server
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		String jsonResponse = "";
		try {

			System.out.println("---- Request JSON to be posted : " + myJSON.toString());
			HttpPost request = new HttpPost(myURL);
			StringEntity params = new StringEntity(myJSON.toString());
			request.addHeader("content-type", "application/json");
			request.setEntity(params);
			HttpResponse httpResponse = httpClient.execute(request);
			// System.out.println("Response after POST Status : " +
			// httpResponse.getStatusLine());
			System.out.println("---- Response after POST : " + httpResponse.toString());
			// handle response here...

			BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

			String inputLine;
			StringBuffer responseText = new StringBuffer();

			while ((inputLine = reader.readLine()) != null) {
				responseText.append(inputLine);
			}
			reader.close();

			System.out.println("----- Response from Node : " + responseText.toString());
			esResponse = responseText.toString();
			// jsonResponse= responseText.toString();
		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("After HTTP POST");

		// Now take screenshot and post it
		/*
		 * if(jsonResponse!=null && !jsonResponse.equals("")) {
		 * System.out.println("Taking screenshot..");
		 * System.out.println("jsonResponse : " + jsonResponse); File screenshotFile =
		 * null; BufferedReader reader=null; CloseableHttpResponse httpResponse = null;
		 * CloseableHttpClient httpclient = null; try { screenshotFile =
		 * ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE); JSONObject
		 * esResponseObject = new JSONObject(jsonResponse);
		 * System.out.println("JSON response : " + jsonResponse); String resID =
		 * esResponseObject.getString("_id");
		 * 
		 * String urlString = this.serverURLPrefix + "/fileupload/uploadScreenshots";
		 * 
		 * 
		 * 
		 * httpclient = HttpClients.custom().build();
		 * 
		 * System.out.println("Before screenshot POST TO : " + urlString); HttpPost
		 * httpPost = new HttpPost(urlString);
		 * 
		 * 
		 * MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		 * builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		 * System.out.println("Screenshot file : " + screenshotFile.getAbsolutePath()
		 * +", " + screenshotFile.getName()); builder.addBinaryBody("photo",
		 * screenshotFile, ContentType.DEFAULT_BINARY, screenshotFile.getName());
		 * builder.addPart("applicationID", new StringBody(applicationName,
		 * ContentType.MULTIPART_FORM_DATA)); //builder.addPart("customerID", new
		 * StringBody(customerID, ContentType.MULTIPART_FORM_DATA));
		 * builder.addPart("esResponseID", new StringBody(resID,
		 * ContentType.MULTIPART_FORM_DATA)); HttpEntity entity = builder.build();
		 * 
		 * httpPost.setEntity(entity);
		 * 
		 * httpResponse = httpclient.execute(httpPost);
		 * 
		 * reader = new BufferedReader(new
		 * InputStreamReader(httpResponse.getEntity().getContent()));
		 * 
		 * String inputLine; StringBuffer response = new StringBuffer();
		 * 
		 * while ((inputLine = reader.readLine()) != null) { response.append(inputLine);
		 * }
		 * 
		 * reader.close(); System.out.println(response.toString()); esResponse =
		 * response.toString();
		 * 
		 * }catch(Exception ex) { ex.printStackTrace(); }finally { if(reader!=null) {
		 * try { reader.close(); } catch (IOException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); } }
		 * 
		 * if(httpclient!=null) { try { httpclient.close(); } catch (IOException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); } }
		 * 
		 * if(httpResponse!=null) { try { httpResponse.close(); } catch (IOException e)
		 * { // TODO Auto-generated catch block e.printStackTrace(); } }
		 * 
		 * } }
		 */

		// System.out.println("esResponse in Transaction Wrapper function" +
		// esResponse);
		return esResponse;

	}

	public JSONObject endTransactionCxPerf(String transactionName, String status, long sla, ChromeDriver driver,
			String filepath, int itr, String methodname, String url) {
		String esResponse = null;

		long pageLoadTime_ms = 0;

		JSONObject trandetails = new JSONObject();
		try {
			if (pageLoad != null && pageLoad.isStarted()) {
				pageLoad.stop();
				pageLoadTime_ms = pageLoad.getTime();
			} else {
				System.out.println("ERROR : pageLoad is " + pageLoad);
				return null;
			}

		} catch (Exception Ex) {
			Ex.printStackTrace();
			System.out.println("esResponse in Transaction Wrapper catch block" + esResponse);
			return trandetails;
		}

		try {
			trandetails.put("responsetime", pageLoadTime_ms);
			// System.out.println("pageLoadTime_ms" + pageLoadTime_ms);
			if (status == "FAIL") {
				trandetails.put("harPath", "");
				trandetails.put("logjson", new JSONObject());
				trandetails.put("performancejson", new JSONObject());
				trandetails.put("recommendation", new JSONArray());
				trandetails.put("TotalRequestsCount", 0);
				// trandetails.put("iterationnum", itr);
				trandetails.put("slastatus", false);
				trandetails.put("TotalTransactionSize", 0);
				trandetails.put("LoadTime", "NA");
				return trandetails;
			}
		} catch (JSONException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		System.out
				.println("********* Transaction name : " + transactionName + ", E2EResponsetime : " + pageLoadTime_ms);
		Har har = null;

		// Only if response time > SLA, save the HAR file entries in DB
//try {
//	Thread.sleep(0);
//} catch (InterruptedException e2) {
//	e2.printStackTrace();
//}
		int nof = 0;
//if (pageLoadTime_ms > sla) {
		if (proxy != null) {
			// if (proxy.getHar() != null) {
			har = proxy.getHar();
			if (har != null) {
				// System.out.println("# of HAR file entries : " +
				// har.getLog().getEntries().size());
				nof = har.getLog().getEntries().size();
			} else {
				System.err.println("HAR file is null for : " + transactionName);
			}
		} else {
			System.err.println("Proxy is null : " + transactionName);
		}

		File harfile1 = new File(filepath + File.separator + transactionName + "_" + itr + ".har");
		try {
			har.writeTo(harfile1);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// }

		String jsEvents = null;
		JSONObject performancejson = new JSONObject();
		JSONObject logjson;
		JSONObject recommend;
		System.out.println(driver.getTitle());
		if (driver != null) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			// try {
			// jsEvents = getPageStats(js);
			try {

				if (methodname.equals("GET") && nof < 5) {
					// System.out.println("Valchecjk");

					// String resourceName = "/info.json";
					// InputStream is =
					// TransactionWrapper.class.getResourceAsStream(harfile1.getAbsolutePath());
					// tokener = new JSONTokener(is);
					// JSONParser
					String content = new String(Files.readAllBytes(Paths.get(harfile1.getAbsolutePath())));
					JSONObject harcheck = new JSONObject(content);
					// System.out.println("Valchecjk:" + harcheck.toString());
					harcheck = harcheck.getJSONObject("log");
					JSONArray jarr = harcheck.getJSONArray("entries");

					for (int k = 0; k < jarr.length(); k++) {
						JSONObject entry = jarr.getJSONObject(k);

						JSONObject reqt = entry.getJSONObject("request");
						if (url.toLowerCase().contains(reqt.getString("url").toLowerCase())
								&& reqt.getString("method").toLowerCase().equals("connect")) {
							JSONObject resp = entry.getJSONObject("response");
							if (resp.getString("_error") != null
									&& resp.getString("_error").toLowerCase().contains("unable to resolve host")) {
								trandetails.put("harPath", harfile1.getAbsolutePath());
								trandetails.put("logjson", new JSONObject());
								trandetails.put("performancejson", new JSONObject());
								trandetails.put("recommendation", new JSONArray());
								trandetails.put("TotalRequestsCount", 0);
								// trandetails.put("iterationnum", itr);
								trandetails.put("slastatus", false);
								trandetails.put("TotalTransactionSize", 0);
								trandetails.put("LoadTime", "NA");
								trandetails.put("itrstatus", "FAIL");

								// System.out.println("return:" + trandetails);
								return trandetails;
							}
						}
					}

				}

				trandetails.put("harPath", harfile1.getAbsolutePath());
				performancejson = pageTimer(js);
				// System.out.println("perfomace" + performancejson.toString());
				int onloadtime = Integer.parseInt((String) performancejson.get("TotalLoadTime"));
				// System.out.println("Check onload" + onloadtime);
				if (onloadtime > sla) {
					trandetails.put("slastatus", "false");
				} else {
					trandetails.put("slastatus", "true");
				}
				trandetails.put("LoadTime", onloadtime);
				trandetails.put("performancejson", performancejson);
				logjson = new JSONObject(harAnalyze.CreateHar(harfile1.getAbsolutePath()));
				trandetails.put("logjson", logjson);
				// System.out.println("logjson" + logjson.toString());
				recommend = new JSONObject(Recommendations.Recommendations(harfile1.getAbsolutePath()));
				trandetails.put("recommendation", recommend.get("recommendation"));
				// System.out.println("recommendation" + recommend.toString());
			} catch (IOException | JSONException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// }
		}

		int totalRequestCount = 0;
		int passRequestCount = 0;
		int failRequestCount = 0;
		long totalTransactionSize = 0;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		String dateString = sdf.format(new Date());

		boolean slastatus;
		if (pageLoadTime_ms < sla)
			slastatus = true;
		else
			slastatus = false;

		String myJSON = "{" + "    \"application\" : \"" + applicationName + "\"," + "    \"transaction\" : \""
				+ transactionName + "\"," + "    \"sampleSource\" : \"SeleniumScript\"," + "	 \"sla\"		 : \""
				+ sla + "\"," + "	 \"slastatus\"		 : \"" + slastatus + "\"," + "              \"region\" : \""
				+ region + "\"," + "              \"status\" : \"" + status + "\"," + "    \"responsetime\" : "
				+ pageLoadTime_ms + "," + jsEvents + "," + "    \"post_date\" : \"" + dateString + "\"";

		if (har != null) {
			myJSON = myJSON + ",\"NetworkStatsCalls\" : true";
			// myJSON = myJSON + ", \"NetworkCalls\" : [";
			List<HarPage> harPageList = har.getLog().getPages();
			// System.out.println("# of harPages : " + harPageList.size());
			Iterator<HarPage> myIterator = harPageList.listIterator();

			List<HarEntry> entries = har.getLog().getEntries();
			JSONArray myJsonArray = new JSONArray();
			for (int i = 0; i < entries.size(); i++) {
				HarEntry entry = entries.get(i);
				JSONObject mySimpleJSONObject = new JSONObject();

				try {
					mySimpleJSONObject.put("url", entry.getRequest().getUrl());
					mySimpleJSONObject.put("status", entry.getResponse().getStatus());
					mySimpleJSONObject.put("statustext", entry.getResponse().getStatusText());
					mySimpleJSONObject.put("method", entry.getRequest().getMethod());
					mySimpleJSONObject.put("mimetype",
							entry.getResponse().getContent().getMimeType().replace("\"", "\\\""));
					long loadTime = entry.getTime();
					if (loadTime <= 0) {
						System.err
								.println("Loadtime = " + loadTime + ", excluding URL : " + entry.getRequest().getUrl());
						continue;
						// loadTime=0;
					}
					mySimpleJSONObject.put("loadtime", loadTime);
					mySimpleJSONObject.put("blockedTime", entry.getTimings().getBlocked());
					mySimpleJSONObject.put("connectTime", entry.getTimings().getConnect());
					mySimpleJSONObject.put("dnsTime", entry.getTimings().getDns());
					mySimpleJSONObject.put("receiveTime", entry.getTimings().getReceive());
					mySimpleJSONObject.put("sendTime", entry.getTimings().getSend());
					mySimpleJSONObject.put("sslTime", entry.getTimings().getSsl());
					mySimpleJSONObject.put("waitTime", entry.getTimings().getWait());

					String startTimeString = sdf.format(entry.getStartedDateTime());
					mySimpleJSONObject.put("starttime", startTimeString);

					long responseSize = entry.getResponse().getBodySize() + entry.getRequest().getHeadersSize();
					if (responseSize <= 0) {
						System.err.println("Response size <0, i.e., = " + responseSize + ", excluding URL : "
								+ entry.getRequest().getUrl());
						// responseSize = 0;
						continue;
					}
					mySimpleJSONObject.put("responsesize", responseSize);

					totalRequestCount++;
					totalTransactionSize = totalTransactionSize + responseSize;
				} catch (JSONException e) {
					e.printStackTrace();
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				myJSON = myJSON + ",\"NetworkCalls\":" + myJsonArray.toString();
			}
		} else {
			myJSON = myJSON + ",\"NetworkStatsCalls\" : false";
		}
		myJSON = myJSON + ",\"TotalRequestsCount\" : " + totalRequestCount + "";
		myJSON = myJSON + ",\"TotalTransactionSize\" : " + totalTransactionSize + "";
		myJSON = myJSON + "}";
		// System.out.println("json : " + myJSON);

		try {
			trandetails.put("TotalRequestsCount", totalRequestCount);
			trandetails.put("TotalTransactionSize", totalTransactionSize);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println("esResponse in Transaction Wrapper function" +
		// esResponse);
		// System.out.println("trandetails" + trandetails.toString());
		return trandetails;

	}

	public JSONObject logJson(String harfile1) throws InterruptedException {
		JSONObject profiling = new JSONObject();
		// List<String> filelist = new ArrayList<String>();
		// Thread.sleep(5000);
		// Har har1 = proxy.getHar();
		// String sFileName1 = folderpath+"\\harfile.json";

		// if (runtype == "withoutcache") {
		// String sFileName2 = folderpath+"\\examples\\harfile.har";
		// File harfile2 = new File(sFileName2);

		// try {
		// har1.writeTo(harfile2);
		// } catch (IOException e) {
		// TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// }
		// File harfile1 = new File(sFileName1);

		// try {
		// har1.writeTo(harfile1);

		// } catch (IOException e) {
		// TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// proxy.endHar();

		// JSONParser jsonparser = new JSONParser();

		try {
			// Object obj = jsonparser.parse(new FileReader(harfile1.getAbsolutePath()));

			JSONObject jsonobject = new JSONObject(new FileReader(harfile1));
			JSONObject log = (JSONObject) jsonobject.get("log");
			JSONArray entries = (JSONArray) log.get("entries");
			// System.out.println(entries.length());

			int script = 0;
			int image = 0;
			int html = 0;
			int css = 0;
			int font = 0;
			int other = 0;
			long temp = 0;
			long tempsize = 0;
			int xhr = 0;
			int video = 0;
			for (int i = 0; i < entries.length(); i++)

			{

				JSONObject entriesget = (JSONObject) entries.get(i);
				// System.out.println("response" +response);
				JSONObject response = (JSONObject) entriesget.get("response");
				JSONObject request = (JSONObject) entriesget.get("request");
				long transfersize = (long) response.get("bodySize");
				tempsize = tempsize + transfersize;
				JSONObject content = (JSONObject) response.get("content");
				if (content != null) {
					String type = (String) content.get("mimeType");
					// System.out.println(type);
					long size = (long) content.get("size");
					temp = temp + size;

					if (type.contains("javascript") || type.contains("js")) {
						script++;
					}

					else if (type.contains("image")) {
						image++;
					}

					else if ((type.contains("html") || (type.contains("text/plain")) || (type.contains("text/html")))) {
						html++;
					} else if (type.contains("css")) {
						css++;
					} else if ((type.contains("font")) || (type.contains("woff2"))
							|| (type.contains("application/octet-stream"))) {
						font++;
					} else if (type.contains("json")) {
						xhr++;
					} else if (type.contains("video")) {
						video++;
					}

					else {

						other++;
					}

				}

			}
			if (script != 0)
				profiling.put("javascript", script);
			profiling.put("image", image);
			profiling.put("html", html);
			profiling.put("css", css);
			profiling.put("font", font);
			profiling.put("other", other);
			profiling.put("xhr", xhr);
			profiling.put("pagesize", tempsize);
			profiling.put("nwrequest", entries.length());
			// profiling.put("runtype", runtype);

//			System.out.println("script" + script);
//			System.out.println("image" + image);
//			System.out.println("html" + html);
//			System.out.println("css" + css);
//			System.out.println("font" + font);
//			System.out.println("xhr" + xhr);
//			System.out.println("other" + other);
//			System.out.println("pagesize" + tempsize);
//			System.out.println("nwrequest" + entries.length());
//			System.out.println("tempsize************" + tempsize);

		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return profiling;

	}
	/*
	 * public void endTransactionEx(String transactionName, String status, long sla,
	 * ChromeDriver driver, String description) { try { pageLoad.stop();
	 * }catch(Exception Ex) { Ex.printStackTrace(); return; }
	 * 
	 * long pageLoadTime_ms = pageLoad.getTime();
	 * 
	 * System.out.println("********* Transaction name : " +
	 * transactionName+", E2EResponsetime : " + pageLoadTime_ms); Har har=null;
	 * 
	 * //Only if response time > SLA, save the HAR file entries in DB
	 * 
	 * if(pageLoadTime_ms>sla) { if(proxy!=null) { if(proxy.getHar()!=null) { har =
	 * proxy.getHar(); System.out.println("# of HAR file entries : " +
	 * har.getLog().getEntries().size()); }else {
	 * System.err.println("HAR file is null for : " + transactionName); } }else {
	 * System.err.println("Proxy is null : " + transactionName); } }
	 * 
	 * String jsEvents = null; if(driver!=null) { JavascriptExecutor js =
	 * (JavascriptExecutor)driver; try{ jsEvents = getPageStats(js);
	 * }catch(Exception ex) { jsEvents= ""; } }
	 * 
	 * 
	 * 
	 * (new MyElasticSearchClient(dbHost,
	 * dbPort)).insertToElasticSearch(transactionName, status, region,
	 * applicationName, pageLoadTime_ms, har, jsEvents); (new
	 * MyInfluxDBClient(dbHost, 8086,
	 * applicationName)).insertDataToInfluxDB(transactionName, status, region,
	 * pageLoadTime_ms);
	 * 
	 * 
	 * }
	 */

	private String getPageStats(JavascriptExecutor js) throws NoSuchSessionException {

		long loadEventEnd = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.loadEventEnd;").toString()).doubleValue();
		long loadEventStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.loadEventStart;").toString()).doubleValue();
		long domComplete = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.domComplete;").toString()).doubleValue();
		long domContentLoadedEventEnd = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.domContentLoadedEventEnd;").toString())
				.doubleValue();
		long domContentLoadedEventStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.domContentLoadedEventStart;").toString())
				.doubleValue();
		long domInteractive = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.domInteractive;").toString()).doubleValue();
		long domLoading = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.domLoading;").toString()).doubleValue();
		long responseEnd = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.responseEnd;").toString()).doubleValue();
		long responseStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.responseStart;").toString()).doubleValue();
		long connectEnd = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.connectEnd;").toString()).doubleValue();
		long requestStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.requestStart;").toString()).doubleValue();
		long secureConnectionStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.secureConnectionStart;").toString())
				.doubleValue();
		long connectStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.connectStart;").toString()).doubleValue();
		long domainLookupEnd = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.domainLookupEnd;").toString())
				.doubleValue();
		long domainLookupStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.domainLookupStart;").toString())
				.doubleValue();
		long fetchStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.fetchStart;").toString()).doubleValue();
		long navigationStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.navigationStart;").toString())
				.doubleValue();
		long redirectEnd = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.redirectEnd;").toString()).doubleValue();
		long redirectStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.redirectStart;").toString()).doubleValue();
		long unloadEventEnd = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.unloadEventEnd;").toString()).doubleValue();
		long unloadEventStart = (long) Double
				.valueOf(js.executeScript("return window.performance.timing.unloadEventStart;").toString())
				.doubleValue();

		long redirectionTime = redirectEnd - navigationStart;
		if (redirectionTime < 0)
			redirectionTime = 0;

		long totalLoadTime = loadEventEnd - fetchStart;
		long totalDOMContentLoadTime = domContentLoadedEventEnd - fetchStart;

//		System.out.println("LoadTime: " + totalLoadTime + ", DOMContentLoadTime: " + totalDOMContentLoadTime
//				+ ", RedirectionTime: " + redirectionTime);
		String pageStatsJSON = "\"LoadTime\" : " + totalLoadTime + "," + "\"DOMContentLoadTime\" : "
				+ totalDOMContentLoadTime + "," + "\"RedirectionTime\" : " + redirectionTime + "," + " \"pageStats\" : "
				+ "{" + "    \"loadEventEnd\" : " + loadEventEnd + "," + "    \"loadEventStart\" : " + loadEventStart
				+ "," + "    \"domComplete\" : " + domComplete + "," + "    \"domContentLoadedEventEnd\" : "
				+ domContentLoadedEventEnd + "," + "    \"domContentLoadedEventStart\" : " + domContentLoadedEventStart
				+ "," + "    \"domInteractive\" : " + domInteractive + "," + "    \"domLoading\" : " + domLoading + ","
				+ "    \"responseEnd\" : " + responseEnd + "," + "    \"responseStart\" : " + responseStart + ","
				+ "    \"connectEnd\" : " + connectEnd + "," + "    \"requestStart\" : " + requestStart + ","
				+ "    \"secureConnectionStart\" : " + secureConnectionStart + "," + "    \"connectStart\" : "
				+ connectStart + "," + "    \"domainLookupEnd\" : " + domainLookupEnd + ","
				+ "    \"domainLookupStart\" : " + domainLookupStart + "," + "    \"fetchStart\" : " + fetchStart + ","
				+ "    \"navigationStart\" : " + navigationStart + "," + "    \"redirectEnd\" : " + redirectEnd + ","
				+ "    \"redirectStart\" : " + redirectStart + "," + "    \"unloadEventEnd\" : " + unloadEventEnd + ","
				+ "    \"unloadEventStart\" : " + unloadEventStart + "}";

		// System.out.println(pageStatsJSON);
		return pageStatsJSON;
	}

	public JSONObject pageTimer(JavascriptExecutor js) throws IOException, JSONException {
		int temp = 0;
		int script = 0;
		int link = 0;
		int img = 0;
		int video = 0;
		int css = 0;
		int textxml = 0, iframe = 0, other = 0;
		JSONObject browserdata = new JSONObject();
		/*
		 * if (browser.equals("IE8")) { System.out.println("\t"+PageName + " Loading");
		 * return; }
		 */

		// System.out.println(" Page Name ****** " + PageName);

		// System.out.println("I am In ");

		long navigationStart = -1;
		long redirectStart = -1;
		long redirectEnd = -1;
		long unloadEventStart = -1;
		long unloadEventEnd = -1;
		long loadEventEnd = -1;
		long fetchStart = -1;
		long connectEnd = -1;
		long connectStart = -1;
		long domainLookupEnd = -1;
		long domainLookupStart = -1;
		long requestStart = -1;
		long responseStart = -1;
		long domInteractive = -1;
		long domLoading = -1;
		long msFirstPaint = -1;
		long responseEnd = -1;
		long domContentLoadedEventStart = -1;
		long domComplete = -1;
		long domContentLoadedEventEnd = -1;
		long loadEventStart = -1;
		String resourceAPI;
		boolean loading = true;
		String Time = null;

		// System.out.println("I am In1 ");

		// Get the current time in Eastern
		// TimeZone timeZone1 = TimeZone.getTimeZone("America/New_York");
		// Calendar calendar = new GregorianCalendar();
		// calendar.setTimeZone(timeZone1);
		// String Hour = String.valueOf(calendar.get(Calendar.HOUR_OF_DAY));
		// String Min = String.valueOf(calendar.get(Calendar.MINUTE));

		// Date dateTime = new Date();
		// System.out.println("Test date/Time:
		// "+requiredFormat.format(dateTime));

		// if (Min.length() == 1) {
		// Time = Hour + ":0" + Min;
		// } else {
		// Time = Hour + ":" + Min;
		// }

		// System.out.println("I am In2 ");
		while (loading) {
			try {
				// System.out.println("I am In3 ");
				//Thread.sleep(200);
				// System.out.println("I am In2=4 ");
				// System.out.println("BROWSER==" + browser);
				// System.out.println("ENV==" + ENV);
				// System.out.println("BUILD==" + BUILD);
				// System.out.println("TESTURL==" + TESTURL);
				// System.out.println("TESTAGENT==" + TESTAGENT);
				// System.out.println("loading...loadEventEnd: " + loadEventEnd);
				loadEventEnd = (long) Double
						.valueOf(js.executeScript("return window.performance.timing.loadEventEnd;").toString())
						.doubleValue();
				 Thread.sleep(1500);
				System.out.println("I am In 4 ");

				if (loadEventEnd != lastLoadTime && loadEventEnd > 0) {
					loading = false;
					lastLoadTime = loadEventEnd;
				} else {
					loading = false;
//					System.out.println(
//							"loading... lastLoadTime: " + lastLoadTime + "\n           loadEventEnd: " + loadEventEnd);
				}
			} catch (Exception e) {
				// e.printStackTrace();
			}
		}

		// System.out.println("I am I5 ");

		try {
			navigationStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.navigationStart;").toString())
					.doubleValue();
		} catch (Exception e) {
			navigationStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.fetchStart;").toString()).doubleValue();
		}
		// System.out.println(" navigationStart: "+navigationStart);

		try {
			redirectStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.redirectStart;").toString())
					.doubleValue();
			// System.out.println(" redirectStart: "+redirectStart);
		} catch (Exception e) {
			redirectStart = -1;
		}

		try {
			redirectEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.redirectEnd;").toString())
					.doubleValue();
			// System.out.println(" redirectEnd: "+redirectEnd);
		} catch (Exception e) {
			redirectEnd = -1;
		}

		try {
			unloadEventStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.unloadEventStart;").toString())
					.doubleValue();
			// System.out.println(" unloadEventStart: "+unloadEventStart);
		} catch (Exception e) {
			unloadEventStart = -1;
		}

		try {
			unloadEventEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.unloadEventEnd;").toString())
					.doubleValue();
			// System.out.println(" unloadEventEnd: "+unloadEventEnd);
		} catch (Exception e) {
			unloadEventEnd = -1;
		}

		try {
			fetchStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.fetchStart;").toString()).doubleValue();
			// System.out.println(" fetchStart: "+fetchStart);
			if (navigationStart <= 0) {
				navigationStart = fetchStart;
			}
		} catch (Exception e) {
			fetchStart = -1;
		}

		try {
			connectEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.connectEnd;").toString()).doubleValue();
			// System.out.println(" connectEnd: "+connectEnd);
		} catch (Exception e) {
			connectEnd = -1;
		}

		try {
			connectStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.connectStart;").toString())
					.doubleValue();
			// System.out.println(" connectStart: "+connectStart);
		} catch (Exception e) {
			connectStart = -1;
		}

		try {
			domainLookupEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domainLookupEnd;").toString())
					.doubleValue();
			// System.out.println(" domainLookupEnd: "+domainLookupEnd);
		} catch (Exception e) {
			domainLookupEnd = -1;
		}

		try {
			domainLookupStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domainLookupStart;").toString())
					.doubleValue();
			// System.out.println(" domainLookupStart: "+domainLookupStart);
		} catch (Exception e) {
			domainLookupStart = -1;
		}

		try {
			requestStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.requestStart;").toString())
					.doubleValue();
			// System.out.println(" requestStart: "+requestStart);
		} catch (Exception e) {
			requestStart = -1;
		}
		try {
			responseStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.responseStart;").toString())
					.doubleValue();
			// System.out.println(" responseStart: "+responseStart);
		} catch (Exception e) {
			responseStart = -1;
		}
		try {
			domInteractive = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domInteractive;").toString())
					.doubleValue();
			// System.out.println(" domInteractive: "+domInteractive);
		} catch (Exception e) {
			domInteractive = -1;
		}

		try {
			domLoading = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domLoading;").toString()).doubleValue();
			// System.out.println(" domLoading: "+domLoading);
		} catch (Exception e) {
			domLoading = -1;
		}

		try {
			msFirstPaint = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.msFirstPaint;").toString())
					.doubleValue();
			// System.out.println(" msFirstPaint: "+msFirstPaint);
		} catch (Exception e) {
			msFirstPaint = -1;
		}

		try {
			responseEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.responseEnd;").toString())
					.doubleValue();
			// System.out.println(" responseEnd: "+responseEnd);
		} catch (Exception e) {
			responseEnd = -1;
		}

		try {
			domContentLoadedEventStart = (long) Double
					.valueOf(
							js.executeScript("return window.performance.timing.domContentLoadedEventStart;").toString())
					.doubleValue();
			// System.out.println(" domContentLoadedEventStart:
			// "+domContentLoadedEventStart);
		} catch (Exception e) {
			domContentLoadedEventStart = -1;
		}

		try {
			domComplete = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domComplete;").toString())
					.doubleValue();
			// System.out.println(" domComplete: "+domComplete);
		} catch (Exception e) {
			domComplete = -1;
		}

		try {
			domContentLoadedEventEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domContentLoadedEventEnd;").toString())
					.doubleValue();
			// System.out.println(" domContentLoadedEventEnd:
			// "+domContentLoadedEventEnd);
		} catch (Exception e) {
			domContentLoadedEventEnd = -1;
		}

		try {
			loadEventStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.loadEventStart;").toString())
					.doubleValue();
			// System.out.println(" loadEventStart: " + loadEventStart);
		} catch (Exception e) {
			loadEventStart = -1;
		}

		try {
			resourceAPI = (String) js.executeScript("return JSON.stringify(performance.getEntriesByType('resource'))");
			// System.out.println(" resourceAPI: "+ js.executeScript("return
			// JSON.stringify(performance.getEntriesByType('resource'))"));
		} catch (Exception e) {
			resourceAPI = (String) js.executeScript("return JSON.stringify(performance.getEntriesByType('resource'))");
			e.printStackTrace();
		}

		org.json.JSONArray jsonarray = new org.json.JSONArray(resourceAPI);

		// System.out.println("Length=========>" + jsonarray.length());
		for (int i = 0; i < jsonarray.length(); i++) {
			org.json.JSONObject obj = jsonarray.getJSONObject(i);

			Integer size = (Integer) obj.get("transferSize");
			temp = temp + size;

			String type = (String) obj.get("initiatorType");

			if (type.equalsIgnoreCase("script")) {
				script++;
			} else if (type.equalsIgnoreCase("link")) {
				link++;
			}

			else if (type.equalsIgnoreCase("img")) {
				img++;
			} else if (type.equalsIgnoreCase("video")) {
				video++;
			} else if (type.equalsIgnoreCase("css")) {
				css++;
			} else if (type.equalsIgnoreCase("xmlhttprequest")) {
				textxml++;
			} else if (type.equalsIgnoreCase("iframe")) {
				iframe++;
			} else {
				other++;
			}

			// System.out.println(size);
		}

//		System.out.println(temp);
//		System.out.println("script" + script);
//		System.out.println("link" + link);
//		System.out.println("img" + img);
//		System.out.println("video" + video);
//		System.out.println("css" + css);
//		System.out.println("xmlhttprequest" + textxml);
//		System.out.println("iframe" + iframe);
//		System.out.println("other" + other);

		String redirect = "";
		String AppCache = "";
		String dnsLookup = "";
		String tcpConnect = "";
		String requestTime = "";
		String serverTime = "";
		String responseTransmit = "";
		String domLoad2Inter = "";
		String domLoad2DomLoaded = "";
		String domLoad2Complete = "";
		String onloadExecute = "";
		String ttFirstByte = "";
		String ttFirstImpression = "";
		String ttOnLoad = "";
		String Total = "";
		String unLoadTime = "";
		String connectTime = "";
		String totalServerTime = "";
		String clientOnLoadTime = "";
		String clientTotalTime = "";
		String initialConnection = "";
		String DomComplete = "";
		String DownloadTime = "";

		// Calculate Metrics

		if (requestStart >= 0 || navigationStart >= 0) {

			initialConnection = String.valueOf(requestStart - navigationStart);
			// System.out.println("initialConnection: " + initialConnection);
		}

		if (requestStart >= 0 || responseStart >= 0) {
			// ttFirstByte = (int) (responseStart-navigationStart);
			ttFirstByte = String.valueOf(responseStart - requestStart);
			// System.out.println("ttFirstByte: "+ttFirstByte);
		}

		if (responseEnd >= 0 || responseStart >= 0) {

			DownloadTime = String.valueOf(responseEnd - responseStart);
			System.out.println("DownloadTime: " + DownloadTime);
		}

		if (domInteractive >= 0 || domLoading >= 0) {
			// domLoad2Inter = (int) (domInteractive-domLoading);
			domLoad2Inter = String.valueOf(domInteractive - domLoading);
			// System.out.println("domLoad2Inter: "+domLoad2Inter);
		}
		if (domContentLoadedEventEnd >= 0 || domLoading >= 0) {
			// domLoad2DomLoaded = (int) (domContentLoadedEventEnd-domLoading);
			domLoad2DomLoaded = String.valueOf(domContentLoadedEventEnd - domLoading);
			// System.out.println("domLoad2DomLoaded: "+domLoad2DomLoaded);
		}
		if (domComplete >= 0 || domLoading >= 0) {
			// domLoad2Complete = (int) (domComplete-domLoading);
			domLoad2Complete = String.valueOf(domComplete - domContentLoadedEventEnd);
			// System.out.println("domLoad2Complete: "+domLoad2Complete);
		}

		if (loadEventEnd >= 0 || navigationStart >= 0) {
			// Total = (int) (loadEventEnd-navigationStart);
			Total = String.valueOf(loadEventEnd - navigationStart);
			// System.out.println("Total: "+Total);
		}

		/*
		 * if (timersEnabled) {
		 * 
		 * if (PageName.isEmpty() == false) { // Print the Performance Timing Values try
		 * { timerlog.append(requiredFormat.format(dateTime) + "\t" + browser + "\t" +
		 * ENV + "\t" + BUILD + "\t" + PageName + "\t" + ttFirstByte + "\t" +
		 * ttFirstImpression + "\t" + ttOnLoad + "\t" + Total + "\t" + redirect + "\t" +
		 * AppCache + "\t" + dnsLookup + "\t" + tcpConnect + "\t" + requestTime + "\t" +
		 * serverTime + "\t" + responseTransmit + "\t" + domLoad2Inter + "\t" +
		 * domLoad2DomLoaded + "\t" + domLoad2Complete + "\t" + onloadExecute + "\t" +
		 * unLoadTime + "\t" + TESTURL + "\t" + TESTAGENT + "\t" + connectTime + "\t" +
		 * totalServerTime + "\t" + clientOnLoadTime + "\t" + clientTotalTime + "\t" +
		 * initialConnection + "\t" + DomComplete + "\t" + DownloadTime + "\n");
		 * 
		 * timerlog.flush();
		 * 
		 * } catch (IOException e1) {
		 * System.out.println("***Failed to wrtite Performance Timings to file.***");
		 * e1.printStackTrace(); } }
		 * 
		 * System.out.println( "\t" + PageName + " Loaded in: " + Total + "ms\t\t(" +
		 * loadEventEnd + " - " + navigationStart + ")"); }
		 */
		// Print all timers if results seem fishy
		if (navigationStart == 0 || loadEventEnd == 0 || (loadEventEnd - navigationStart) < 0
				|| (loadEventEnd - navigationStart) > 80000) {
//			System.out.println("   responseEnd: " + responseEnd);
//			System.out.println("   msFirstPaint: " + msFirstPaint);
//			System.out.println("   domLoading: " + domLoading);
//			System.out.println("   domComplete: " + domComplete);
//			System.out.println("   domInteractive: " + domInteractive);
//			System.out.println("   responseStart: " + responseStart);
//			System.out.println("   requestStart: " + requestStart);
//			System.out.println("   domainLookupStart: " + domainLookupStart);
//			System.out.println("   domainLookupEnd: " + domainLookupEnd);
//			System.out.println("   connectStart: " + connectStart);
//			System.out.println("   domContentLoadedEventEnd: " + domContentLoadedEventEnd);
//			System.out.println("   connectEnd: " + connectEnd);
//			System.out.println("   fetchStart: " + fetchStart);
//			System.out.println("   unloadEventEnd: " + unloadEventEnd);
//			System.out.println("   unloadEventStart: " + unloadEventStart);
//			System.out.println("   redirectEnd: " + redirectEnd);
//			System.out.println("   redirectStart: " + redirectStart);
//			System.out.println("   loadEventStart: " + loadEventStart);
//			System.out.println("   navigationStart: " + navigationStart);
//			System.out.println("   loadEventEnd: " + loadEventEnd);
//			System.out.println("   domContentLoadedEventStart: " + domContentLoadedEventStart);
			/*
			 * try { Thread.sleep(30000); } catch (InterruptedException e) { // TODO
			 * Auto-generated catch block // e.printStackTrace(); }
			 */
		}

		browserdata.put("DOMLoadingtoComplete", domLoad2Complete);
		browserdata.put("DOMLoadingtoLoaded", domLoad2DomLoaded);
		browserdata.put("ClientonLoadTime", clientOnLoadTime);
		browserdata.put("onLoadTime", ttOnLoad);
		browserdata.put("CacheLookup", AppCache);
		browserdata.put("onLoadExecuteTime", onloadExecute);
		// browserdata.put("PageName", PageName);
		browserdata.put("DNSLookup", dnsLookup);
		browserdata.put("RedirectTime", redirect);
		// browserdata.put("Build", BUILD);
		browserdata.put("ResponseTransmitTime", responseTransmit);
		browserdata.put("unLoadTime", unLoadTime);
		browserdata.put("InitialConnection", initialConnection);
		browserdata.put("ConnectTime", connectTime);
		// browserdata.put("TestAgent", TESTAGENT);
		browserdata.put("TimeToFirstByte", ttFirstByte);
		browserdata.put("ClientTotalTime", clientTotalTime);
		browserdata.put("DomComplete", DomComplete);
		browserdata.put("TotalLoadTime", Total);
		browserdata.put("TCPConnect", tcpConnect);
		// browserdata.put("Date/Time", requiredFormat.format(dateTime));
		browserdata.put("RequestSubmit", requestTime);
		browserdata.put("ServerTime", serverTime);
		// browserdata.put("TestURL", TESTURL);
		browserdata.put("DownloadTime", DownloadTime);
		// browserdata.put("Environment", ENV);
		browserdata.put("FirstImpression", ttFirstImpression);
		browserdata.put("TotalServerTime", totalServerTime);
		// browserdata.put("Browser", browser);
		browserdata.put("DOMLoadingtoInteractive", domLoad2Inter);
		browserdata.put("PageSize", temp);
		browserdata.put("nwrequest", jsonarray.length());
		browserdata.put("script", script);
		browserdata.put("link", link);
		browserdata.put("img", img);
		browserdata.put("video", video);
		browserdata.put("css", css);
		browserdata.put("xmlhttprequest", textxml);
		browserdata.put("iframe", iframe);
		browserdata.put("other", other);
		// browserdata.put("runtype", runtype);

		return browserdata;
	}

	public void pause(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
