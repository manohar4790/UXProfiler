package com.cts;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class Recommendations {
	public static String Recommendations(String folderpath) {
		// TODO Auto-generated method stub

		String harfile = folderpath;
		JSONParser parser = new JSONParser();
		JSONObject recommendation = new JSONObject();
		JSONArray array = new JSONArray();

		try {

			Object obj = parser.parse(new FileReader(harfile));

			// TODO Auto-generated method stub

			JSONObject jsonObject = (JSONObject) obj;

			// //String name = (String) jsonObject.get("Name");
			// String author = (String) jsonObject.get("Author");
			// //JSONArray companyList = (JSONArray)
			// jsonObject.get("Company List");

			JSONObject log = (JSONObject) jsonObject.get("log");
			JSONArray entries = (JSONArray) log.get("entries");

			NetworkRecommend t1 = new NetworkRecommend();
			t1.totalrequests = entries.size();

			t1.errorurls = t1.errorenousurls(entries);

			////////////////////////////////////// RULE
			////////////////////////////////////// 1/////////////////////////////////////////////////
			JSONObject rule1 = new JSONObject();

			rule1.put("ruleHeader", "Errorneous Requests");

			List<String> list400 = new ArrayList<String>();
			List<String> list302 = new ArrayList<String>();

			list400 = t1.errorurls.get("404");
			list302 = t1.errorurls.get("302");

			// System.out.println("Rule 4 Errorneous requests:");

			if (!list400.isEmpty()) {
				// System.out.println("Below errorenous requests(400/404) were observed:" +
				// "\n\n" + list400);
				String message;
				message = "";
				message = list400.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");

				rule1.put("Message", "Below resources have status code 400/404:" + "\n"
						+ message.toString().replaceAll("http", "\n" + " \u2022" + "http"));
				rule1.put("Recommendation", "Resolve 400/404 resources else remove the unwanted calls");
			} else {
				rule1.put("Message", "No 400/404 HTTP errors found");
				rule1.put("Recommendation", "none");
				// System.out.println("No errorenous requests were observed");
			}

			array.add(rule1);

			////////////////////////////////////// RULE
			////////////////////////////////////// 2/////////////////////////////////////////////////
			JSONObject rule2 = new JSONObject();

			rule2.put("ruleHeader", "Avoid Redirects");

			if (!list302.isEmpty()) {
				// System.out.println("Below requests with 302 status code were observed:" +
				// "\n\n" + list302);
				String message;
				message = "";
				message = list302.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");

				rule2.put("Message", "Status code 302 was observed for the url's:" + "\n\n"
						+ message.toString().replaceAll("http", "\n" + " \u2022" + "http"));
				rule2.put("Recommendation",
						"Provide direct url to the resource which will reduce the unwanted roundtrip of network calls.");
			} else {
				// System.out.println("No redirects were observed in the page");
				rule2.put("Message", "none");
				rule2.put("Recommendation", "none");
			}
			array.add(rule2);

			////////////////////////////////////// RULE
			////////////////////////////////////// 3/////////////////////////////////////////////////

			t1.condition3 = t1.findDuplicates(entries);

			JSONObject rule3 = new JSONObject();

			rule3.put("ruleHeader", "Avoid Duplicate calls");

			// System.out.println("Rule 3 Duplicate calls in the page:");

			if (!t1.condition3.isEmpty()) {
				// System.out.println("Below duplicate calls are observed in the page:" + "\n\n"
				// + t1.condition3);
				String message;
				message = "";
				message = t1.condition3.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");

				rule3.put("Message", "Below duplicate calls were observed:" + "\n"
						+ message.toString().replaceAll("http", "\n" + " \u2022" + "http"));
				rule3.put("Recommendation",
						"Duplicate call needs to be avoided and also remove unnecessary network calls");
			} else {
				rule3.put("Message", "none");
				rule3.put("Recommendation", "none");
			}

			array.add(rule3);

////////////////////////////////////// RULE
			////////////////////////////////////// 4/////////////////////////////////////////////////
			JSONObject rule4 = new JSONObject();

			t1.condition1 = t1.checkcachecontrol(entries);
			// System.out.println("Total number of requests in the page is :" +
			// t1.totalrequests);

			// System.out.println("Rule 1 Cache Control:");

			rule4.put("ruleHeader", "Leverage Browsing Cache");
			int chk = 0;
			String message;
			message = "";

			if (!t1.condition1.get("Expiry").isEmpty()) {
				// System.out.println("Expires Header is not mentioned for the below resources"
				// + "\n" + t1.condition1.get("Expiry"));
				// rule2.put("Expiries url", t1.condition1.get("Expiry"));
				message = "Url's without any expiry header:" + "\n" + t1.condition1.get("Expiry").toString()
						.substring(1).replaceFirst("]", "").replaceAll(",", "\n");

				// System.out.println("rule2myList@@@@" + rule2myList);
				chk = 1;
			}

			if (!t1.condition1.get("CacheControl").isEmpty()) {
//				System.out.println("Cache Control Header is not mentioned for the below resources"
//						+ t1.condition1.get("CacheControl"));
				// rule2.put("CacheControl url",
				// t1.condition1.get("CacheControl"));
				message = message + "Url's without cache control header:" + "\n" + t1.condition1.get("CacheControl")
						.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");

				// System.out.println("rule2myList@@@@" + rule2myList);
				chk = 1;
			}
			if (!t1.condition1.get("CacheStatus").isEmpty()) {
//				System.out.println(
//						"Below resources are having 304 as status code" + "\n" + t1.condition1.get("CacheStatus"));
				message += "\n\n" + "Url's 304 status:" + "\n" + t1.condition1.get("CacheStatus").toString()
						.substring(1).replaceFirst("]", "").replaceAll(",", "\n");

				// System.out.println("rule2myList@@@@" + rule2myList);
				chk = 1;
			}

			// message+=message.substring(0, message.indexOf("?"));
			/*
			 * message+=message.substring(message.indexOf("?")+1); message.trim();
			 * message.toString().replaceAll("http", "\n" + " \u2022"+"http");
			 */
			/*
			 * List<String> rule2myList = new ArrayList<String>();
			 * FileUtils.writeStringToFile(new
			 * File("C:\\AutomationScripts\\Performance_SingleURL\\rule22.txt"), message);
			 * 
			 * File rule2file = new
			 * File("C:\\AutomationScripts\\Performance_SingleURL\\rule22.txt"); FileReader
			 * rule2fr = new FileReader(rule2file); BufferedReader rule2br = new
			 * BufferedReader(rule2fr); String rule22line;
			 * 
			 * while ((rule22line = rule2br.readLine()) != null) { // process the line
			 * System.out.println("line=========================>" + rule22line); if
			 * (rule22line.startsWith("http") || rule22line.contains("http")) { rule22line =
			 * "\n" + " \u2022" + rule22line;
			 * System.out.println("line inside=========================>" + rule22line);
			 * rule2myList.add(rule22line); } }
			 */
			if (chk == 0) {
				rule4.put("Message", "none");
				rule4.put("Recommendation", "none");
			} else {
				// System.out.println("Check" + rule2myList);
				rule4.put("Message", message.toString().replaceAll("http", "\n" + " \u2022" + "http"));
				rule4.put("Recommendation",
						"For having a good caching startegy, it is recommended to have cache control and expires header for all the resources.Also, as a best practice it is recommended that no resources should get 304 status.");
			}
			array.add(rule4);

////////////////////////////////////// RULE
			////////////////////////////////////// 5/////////////////////////////////////////////////

			t1.condition2 = t1.findCompression(entries);
			JSONObject rule5 = new JSONObject();

			rule5.put("ruleHeader", "Apply Compression Technique");
			// System.out.println("Rule 2 Compression Check:");
			if (!t1.condition2.isEmpty()) {
				// System.out.println("Compression is not applied to below resources:" + "\n" +
				// t1.condition2);

				message = t1.condition2.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");

				// System.out.println("myList@@@@" + message.toString().replaceAll("http", "\n"
				// + " \u2022"+"http"));
				rule5.put("Message", "No compression methodologies has been applied for the below URL's :" + "\n"
						+ message.toString().replaceAll("http", "\n" + " \u2022" + "http"));
				rule5.put("Recommendation",
						"It is recommended to apply gzip/deflate/br compression techniques to the resources by which we can minimize the amount of data getting transferred");

			} else {
				rule5.put("Message", "none");
				rule5.put("Recommendation", "none");

			}
			array.add(rule5);

			////////////////////////////////////// RULE
			////////////////////////////////////// 6/////////////////////////////////////////////////
			t1.cssurls = t1.getDomainurls(entries, ".css");

			JSONObject rule6 = new JSONObject();

			rule6.put("ruleHeader", "Combine CSS and JS");

			message = "";
			chk = 0;
			for (String key : t1.cssurls.keySet()) {
				if (t1.cssurls.get(key).size() > 1) {
					chk = 1;
					message += "\n\n" + "Below urls from the domain-" + key + " are the candidates for merging css:"
							+ "\n\n"
							+ t1.cssurls.get(key).toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");
				}
			}

			t1.jsurls = t1.getDomainurls(entries, ".js");

			int chk1 = 0;
			for (String key : t1.jsurls.keySet()) {
				if (t1.jsurls.get(key).size() > 1) {
					chk1 = 1;
					message += "\n\n" + "Below urls from the domain-" + key + " are the candidates for merging js:"
							+ "\n\n"
							+ t1.jsurls.get(key).toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");
				}
			}

			// System.out.println("myList@@@@" + message.toString().replaceAll("http", "\n"
			// + " \u2022"+"http"));
			if (chk == 1 || chk1 == 1) {
				rule6.put("Message", "Please find the below URL: " + "\n"
						+ message.toString().replaceAll("http", "\n" + " \u2022" + "http"));
				rule6.put("Recommendation",
						"Combine the candidate files into a single file or lesser multiple files which would reduce the number of network calls in the page.");
			} else {
				rule6.put("Message", "none");
				rule6.put("Recommendation", "none");
			}
			array.add(rule6);

			String Htmlcontent = t1.findHtmlContent(entries);
			// System.out.println(Htmlcontent);
			if (Htmlcontent != "") {

				/*------Check import tag in the document-------*/
				int imprtcnt = 0;
				// compile("@import");
				Pattern pattern = Pattern.compile("@import", Pattern.CASE_INSENSITIVE);
				Matcher matcher = pattern.matcher(Htmlcontent);
				int count = 0;
				while (matcher.find())
					count++;

				imprtcnt = count;

				Document html = null;
				Document body = null;
				Document head = null;
				html = Jsoup.parse(Htmlcontent);
				body = Jsoup.parse(html.getElementsByTag("body").toString());
				head = Jsoup.parse(html.getElementsByTag("head").toString());

				pattern = Pattern.compile(">registersod", Pattern.CASE_INSENSITIVE);
				count = 0;
				while (matcher.find())
					count++;

				int totSODCount = count;
				int headSODCount = 0;

				matcher = pattern.matcher(html.getElementsByTag("head").toString().toLowerCase());
				pattern = Pattern.compile(">registersod", Pattern.CASE_INSENSITIVE);
				count = 0;
				while (matcher.find())
					count++;
				headSODCount = count;

				/************************************************/
				/*********************
				 * Collect details of images
				 ********************/
				int emptyLinkCount = 0;
				int noscaleCount = 0;
				// String noScaleImgs[];
				// String scaleImgs[];
				int totImgCount = html.select("img").size();
				List<String> noScaleImgs = new ArrayList<String>();
				List<String> scaleImgs = new ArrayList<String>();

				for (int i = 0; i < totImgCount; i++) {
					// Element temp = html.select("img").get(i).at;
					if (html.select("img").get(i).attr("src") == "") {
						emptyLinkCount = emptyLinkCount + 1;
					}

					if (html.select("img").get(i).attr("width") == "" && html.select("img").get(i).attr("height") == ""
							&& html.select("img").get(i).attr("style") == ""
							&& html.select("img").get(i).attr("src") != "") {
						noscaleCount = noscaleCount + 1;
						noScaleImgs.add(html.select("img").get(i).attr("src"));
					} else {
						scaleImgs.add(html.select("img").get(i).attr("src"));
					}
				}

				for (int i = 0; i < html.select("script[src]").size(); i++) {
					if (html.select("script[src]").get(i).attr("src") == "") {
						emptyLinkCount = emptyLinkCount + 1;
					}
				}

				for (int i = 0; i < html.select("link[href]").size(); i++) {
					if (html.select("link[href]").get(i).attr("href") == "") {
						emptyLinkCount = emptyLinkCount + 1;
					}
				}

				/******************************************************************************************************************/

				/***************
				 * Tags with empty SRC or HREF
				 ********************/

				JSONObject rule7 = new JSONObject();

				rule7.put("ruleHeader", "Empty SRC or HREF Tags");
				//
				if (emptyLinkCount != 0) {
					rule7.put("Message", emptyLinkCount
							+ " instance(s) of empty SRC or HREF used in IMG,SCRIPT or LINK tag was found in the HTML document.");
					rule7.put("Recommendation",
							"Remove the tags from the HTML document to avoid unnecessary HTTP call to server.");
				} else {
					rule7.put("Message", "none");
					rule7.put("Recommendation", "none");
				}

				array.add(rule7);

				int intJSCount = html.select("script").size() - (html.select("script[src]").size() + totSODCount);
				JSONObject rule8 = new JSONObject();
				rule8.put("ruleHeader", "Make JS as external");

				if (intJSCount > 0) {
					rule8.put("Message",
							intJSCount + " instance(s) of internal Javascript has been identified in the HTML page");
					rule8.put("Recommendation", "Make internal javascript to external. if javascript is not simple.");
				} else {
					rule8.put("Message", "none");
					rule8.put("Recommendation", "none");

				}
				array.add(rule8);

				JSONObject rule9 = new JSONObject();
				rule9.put("ruleHeader", "PUT javaScript at bottom");

				int jscntHead = (head.select("script").size()
						- (head.select("script[async]").size() + head.select("script[defer]").size() + headSODCount));
				// head.select("script:not(script[async],script[defer])").size();

				List<String> jsList = new ArrayList<String>();
				if (jscntHead > 0) {
					for (int i = 0; i < head.select("script:not(script[async],script[defer])").size(); i++) {
						if (head.select("script:not(script[async],script[defer])").get(i).attr("src") != "") {
							jsList.add(head.select("script:not(script[async],script[defer])").get(i).attr("src"));
						}
					}
					// called in HEAD without ASYNC or DEFER attribute can block
					// parallel download of resources.
					if (jsList.size() > 0) {
						if (jscntHead == jsList.size()) {
							rule9.put("Message", jscntHead
									+ " instance(s) of Javascript has been called in HEAD without ASYNC or DEFER attribute can block parallel download of resources."
									+ "\n\n" + " Below are the identified external javascripts:" + "\n\n"
									+ jsList.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
						} else {
							rule9.put("Message", jscntHead
									+ " instance(s) of Javascript has been called in HEAD without ASYNC or DEFER attribute can block parallel download of resources."
									+ "\n" + (jscntHead - jsList.size()) + " instance(s) of inline javascript and "
									+ jsList.size() + " instance(s) of external java script has been found." + "\n\n"
									+ "Below are the identified external javascripts:" + "\n\n"
									+ jsList.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
						}
					} else {
						rule9.put("Message", jscntHead
								+ " instance(s) of Inline Javascript has been called in HEAD without ASYNC or DEFER attribute which can block parallel download of resources.");
					}
					rule9.put("Recommendation",
							"Move the Javascript to the bottom of the HTML or use ASYNC or DEFER attribute");

				} else {
					rule9.put("Message", "none");
					rule9.put("Recommendation", "none");
				}
				array.add(rule9);

				int cssBodyCount = body.select("style").size();
				JSONObject rule10 = new JSONObject();
				rule10.put("ruleHeader", "PUT CSS at top");
				if (cssBodyCount > 0) {
					rule10.put("Message", cssBodyCount + " instance(s) of CSS stylesheet has been found in BODY");
					rule10.put("Recommendation",
							"Specifying external stylesheet and inline style blocks in the body of an HTML document can negatively affect the browser's rendering performance. Move the CSS stylsheet to top of the HTML");
				} else {
					rule10.put("Message", "none");
					rule10.put("Recommendation", "none");
				}
				array.add(rule10);

				JSONObject rule11 = new JSONObject();

				rule11.put("ruleHeader", "Dimension of images needs to be mentioned");
				// .toString().substring(1).replaceFirst("]", "")
				if (noscaleCount != 0) {

					message = noScaleImgs.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");

					// System.out.println("myList@@@@" + message.toString().replaceAll("http", "\n"
					// + " \u2022"+"http"));

					rule11.put("Message", noscaleCount
							+ " instance(s) of IMG has no WIDTH or HEIGHT or STYLE defined.Below are the images where dimensions has not been mentioned:"
							+ "\n" + message.toString().replaceAll("http", "\n" + " \u2022" + "http"));
					rule11.put("Recommendation",
							"Be sure to specify dimensions on the image element or block-level parent to avoid browser reflow or repaint.");
				} else {
					rule11.put("Message", "none");
					rule11.put("Recommendation", "none");
				}

				array.add(rule11);

				JSONObject rule12 = new JSONObject();
				rule12.put("ruleHeader", "Avoid image scaling");

				if ((totImgCount - noscaleCount) > 0) {

					message = scaleImgs.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");

					// System.out.println("rule12myList@@@@" + message.toString().replaceAll("http",
					// "\n" + " \u2022"+"http"));
					rule12.put("Message", (totImgCount - noscaleCount)
							+ " instance(s) of IMG has scaling defined. Below are the images where scaling has been defined:"
							+ "\n" + message.toString().replaceAll("http", "\n" + " \u2022" + "http"));
					rule12.put("Recommendation", "Make sure right size image used and avoid scaling in HTML");
				} else {
					rule12.put("Message", "none");
					rule12.put("Recommendation", "none");
				}

				array.add(rule12);

				/********** Check Use of IFrames *******************/
				int emptyiFrameCnt = html.select("IFRAME").size();

				JSONObject rule13 = new JSONObject();

				rule13.put("ruleHeader", "Use of IFRAMES");

				if (emptyiFrameCnt != 0) {
					rule13.put("Message", "IFRAMES has been used in " + emptyiFrameCnt + " places");
					rule13.put("Recommendation",
							"If the contents are nor important than the main page, set these IFRAME(S) SRC dynamically after high priority resources are downloaded.");
				} else {
					rule13.put("Message", "none");
					rule13.put("Recommendation", "none");
				}

				array.add(rule13);

				JSONObject rule14 = new JSONObject();
				// matcher.
				rule14.put("ruleHeader", "Check for IMPORT tag");
				// System.out.println(imprtcnt);
				if (imprtcnt != 0) {
					rule14.put("Message", "@IMPORT statement has been used for stylesheets in HTML document around "
							+ imprtcnt + " places");
					rule14.put("Recommendation",
							"Instead use a LINK tag which allows the browser to download stylesheets in parallel.");
				} else {
					rule14.put("Message", "none");
					rule14.put("Recommendation", "none");
				}

				array.add(rule14);

				JSONObject rule15 = new JSONObject();
				rule15.put("ruleHeader", "Avoid charset in meta tag");

				if (head.select("meta").attr("content").contains("charset")) {
					rule15.put("Message", "Charset has been mentioned in the meta tag of HTML document");
					rule15.put("Recommendation",
							"Specifying a character set in a meta tag disables the lookahead downloader in IE8.To improve resource download parallelization move the character set to the HTTP ContentType response header.");
				} else {
					rule15.put("Message", "none");
					rule15.put("Recommendation", "none");

				}
				array.add(rule15);

				t1.timetakingurls = t1.timeconsuming(entries);

				////////////////////////////////////// RULE
				////////////////////////////////////// 7/////////////////////////////////////////////////
				JSONObject rule16 = new JSONObject();
				rule16.put("ruleHeader", "Server time consuming");
				message = t1.timetakingurls.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");

				if (!t1.timetakingurls.isEmpty()) {
					rule16.put("Message", "Response time for the below individual request is over 500ms:" + "\n"
							+ message.toString().replaceAll("http", "\n" + " \u2022" + "http"));
					rule16.put("Recommendation",
							"The requests seems to be time consuming from server/network side. This needs to be profiled");
				} else {
					rule16.put("Message", "none");
					rule16.put("Recommendation", "none");
				}
				array.add(rule16);

			}

			JSONObject rule17 = new JSONObject();

			rule17.put("ruleHeader", "Validate number of requests in a page");
			if (t1.totalrequests >= 10) {
				rule17.put("Message", "Total number of requests in the page is :" + +t1.totalrequests
						+ ".Consider reducing total number of resources getting downloaded.");
				rule17.put("Recommendation",
						"If possible combine multiple js/css files from same domain to single js/css and CSS spriting for images also reduces the number of network calls.");
			} else {
				rule17.put("Message", "Total number of requests in the page is :" + +t1.totalrequests
						+ "Number of requests per page is within the industry standard.");
				rule17.put("Recommendation", "none");
			}
			array.add(rule17);

			// System.out.println(array);

			recommendation.put("recommendation", array);
			// recommendation.put("pagename", pagename);
			// System.out.println("recommendation=======>"+"----------->"+pagename);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return recommendation.toString();

	}

}
