package com.cts.exceptions;

public class SeleniumObjectNotFoundException extends Exception{

}
