package sample;

import java.io.File;

import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.cts.SeleniumScriptExecutorForCxPerf;

public class SampleSelenium {
	public static void main(String[] args) throws JSONException {

		SeleniumScriptExecutorForCxPerf uxcf = new SeleniumScriptExecutorForCxPerf("token");
		String jsn = args[0];
		System.out.println(jsn);
		JSONObject json = new JSONObject(jsn);
		System.out.println(json);
		System.setProperty("webdriver.chrome.driver", "C:\\CxPerf\\driver\\chromedriver.exe");
		ChromeDriver driver = null;
		Proxy seleniumProxy = uxcf.initializeSelenium(json);
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
		capabilities.setCapability("acceptInsecureCerts", true);

		capabilities.setJavascriptEnabled(true);
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
		ChromeDriverService service = new ChromeDriverService.Builder()
				.usingDriverExecutable(new File("C:\\CxPerf\\driver\\chromedriver.exe")).usingAnyFreePort().build();

		ChromeOptions options = new ChromeOptions();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		// options.merge(capabilities);

		driver = new ChromeDriver(service, capabilities);

//		uxcf.StartTransactionForSelenium("Launch");
//
//		driver.get("https://www.amazon.com");
//
//		uxcf.EndTransactionForPass("Launch", 3000, driver);
//
//		uxcf.StartTransactionForSelenium("Launch");
		String ApplicationURL = "https://profile.w3schools.com/log-in?redirect_url=https%3A%2F%2Fmy-learning.w3schools.com";
		String uname = "hema";
		String pwd = "latha";
		uxcf.StartTransactionForSelenium("Launch");
		driver.get(ApplicationURL);
		uxcf.EndTransactionForPass("Launch", 3000, driver);

		// 2. Click 'email'
		uxcf.StartTransactionForSelenium("Email");
		// driver.findElementsByCssSelector("[name='email']");
		driver.findElement(By.cssSelector("[name='email']")).click();
		System.out.println(" email ");
		uxcf.EndTransactionForPass("Email", 3000, driver);

		uxcf.stopcxCollector();

		driver.quit();
	}
}
